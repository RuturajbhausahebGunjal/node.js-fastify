import { IStudentRepo } from '@core/repositories/student.repository';
import { StudentTrainingPayload } from '@core/entities/student.training.payload';
import { StudentBaap } from '@core/entities/student.training.entity';
import StudentModel from '@infrastructure/database/models/student.model';

export class StudentRepository implements IStudentRepo {
    async createStudent(studentPayload: StudentTrainingPayload): Promise<StudentBaap> {
        const student = await StudentModel.create(studentPayload); // ORM
        return student as StudentBaap;
    }

    async getStudent(uuid: string): Promise<StudentBaap | undefined> {
        const student = await StudentModel.findByPk(uuid);
        return student ? (student as StudentBaap) : undefined;
    }
}


