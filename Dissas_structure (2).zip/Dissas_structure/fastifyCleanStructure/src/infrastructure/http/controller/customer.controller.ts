import type { ICustomerRepo } from "@core/repositories/customer.repository";
import type { FastifyRequest, FastifyReply } from "fastify";
import { CustomerService } from "@core/services/customer.services";
import type { CustomerPayload } from "@core/entities/customer.payload";

// import { CustomerParamsType } from "../schemas/customerSchema";

export const createCustomer = (customerRepository: ICustomerRepo) =>
    async function (request: FastifyRequest, reply: FastifyReply) {
        try {
            const customer = await CustomerService(customerRepository).createCustomer(request.body as CustomerPayload);
            void reply.status(201).send(customer);
        } catch (error) {
            console.error(error);
            void reply.status(500).send({ message: "Failed to create customer", error });
        }
    };

export const getCustomer = (customerRepository: ICustomerRepo) =>
    async function (request: FastifyRequest, reply: FastifyReply) {
        try {
            const customer = await CustomerService(customerRepository).getCustomer(request.params as string);
            if (customer) {
                void reply.status(200).send(customer);
            } else {
                void reply.status(404).send({ message: "Customer not found" });
            }
        } catch (error) {
            console.error(error);
            void reply.status(500).send({ message: "Failed to fetch customer", error });
        }
    };

export const getAllCustomer = (customerRepository: ICustomerRepo) =>
    async function (_request: FastifyRequest, reply: FastifyReply) {
        try {
            const customers = await CustomerService(customerRepository).getAllCustomer();
            void reply.status(200).send(customers);
        } catch (error) {
            console.error(error);
            void reply.status(500).send({ message: "Failed to fetch customers", error });
        }
    };

export const updateCustomer = (customerRepository: ICustomerRepo) =>
    async function (request: FastifyRequest, reply: FastifyReply) {
        try {
            const { params, body } = request;
            const updatedCustomer = await CustomerService(customerRepository).updateCustomer(
                params as string,
                body as Partial<CustomerPayload>
            );
            if (updatedCustomer) {
                void reply.status(200).send(updatedCustomer);
            } else {
                void reply.status(404).send({ message: "Customer not found" });
            }
        } catch (error) {
            console.error(error);
            void reply.status(500).send({ message: "Failed to update customer", error });
        }
    };

export const deleteCustomer = (customerRepository: ICustomerRepo) =>
    async function (request: FastifyRequest, reply: FastifyReply) {
        try {
            const { params } = request;
            await CustomerService(customerRepository).deleteCustomer(params as string);
            void reply.status(200).send({ message: "Customer deleted successfully" });
        } catch (error) {
            console.error(error);
            void reply.status(404).send({ message: "Customer not found", error });
        }
    };






