import { RouteOptions } from 'fastify';
import { IStudentRepo } from '@core/repositories/student.repository';
import { ICustomerRepo } from '@core/repositories/customer.repository'; // Import ICustomerRepo
import { studentRoutes } from '@infrastructure/http/routes/student.routes';
import { customerRoutes } from '@infrastructure/http/routes/customer.routes'; // Import customerRoutes

export default (
    studentRepository: IStudentRepo,
    customerRepository: ICustomerRepo // Accept customerRepository as an argument
): RouteOptions[] => [
    ...studentRoutes(studentRepository),
    ...customerRoutes(customerRepository), // Add customerRoutes
];





