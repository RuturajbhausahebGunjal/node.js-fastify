import { RouteOptions } from "fastify";
import {
    createCustomer,
    getCustomer,
    getAllCustomer,
    updateCustomer,
    deleteCustomer,
} from "../controller/customer.controller";
import { ICustomerRepo } from "@core/repositories/customer.repository";

export const customerRoutes = (customerRepository: ICustomerRepo): RouteOptions[] => [
    {
        method: 'POST',
        url: '/create/customer',
        handler: createCustomer(customerRepository),
    },
    {
        method: 'GET',
        url: '/getCustomer/:id',
        handler: getCustomer(customerRepository),
    },
    {
        method: 'GET',
        url: '/getAllCustomer',
        handler: getAllCustomer(customerRepository),
    },
    {
        method: 'PUT',
        url: '/updateCustomer/:id',
        handler: updateCustomer(customerRepository),
    },
    {
        method: 'DELETE',
        url: '/deleteCustomer/:id',
        handler: deleteCustomer(customerRepository),
    },
];
