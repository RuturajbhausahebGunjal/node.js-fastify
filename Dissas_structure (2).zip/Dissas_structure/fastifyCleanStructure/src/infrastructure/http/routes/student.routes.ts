import { RouteOptions } from 'fastify';
import { createStudent } from '@infrastructure/http/controller/student.controller';
import { IStudentRepo } from '@core/repositories/student.repository';

export const studentRoutes = (studentRepository: IStudentRepo): RouteOptions[] => [
    {
        method: 'POST',
        url: '/studentUser',
        handler: createStudent(studentRepository),
    }
];
