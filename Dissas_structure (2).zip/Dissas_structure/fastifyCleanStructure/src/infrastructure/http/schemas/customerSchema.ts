// import { FastifySchema } from "fastify";
// import { Static, Type } from "@sinclair/typebox";

// // Course Response Schema
// export const CourseResponse = Type.Object({
//     uuid: Type.String({ description: 'Unique identifier for the course' }),
//     name: Type.String({ description: 'Course name' }),
//     cid: Type.String({ description: 'Course code or ID' }),
//     year: Type.Integer({ description: 'Year of the course' }),
// });

// // Customer Payload Schema
// export const CustomerPayload = Type.Object({
//     name: Type.String({ description: 'Name of the customer' }),
//     email: Type.String({ description: 'Email of the customer' }),
//     password: Type.String({ description: 'Password for customer login' }),
//     phone: Type.Integer({ description: 'Phone number of the customer' }),
//     courseId: Type.String({ description: 'ID of the associated course' }),
// });

// // Customer Response Schema
// export const CustomerResponse = Type.Object({
//     uuid: Type.Optional(Type.String({ description: 'Unique identifier for the customer' })),
//     name: Type.Optional(Type.String({ description: 'Name of the customer' })),
//     email: Type.Optional(Type.String({ description: 'Email of the customer' })),
//     password: Type.Optional(Type.String({ description: 'Password of the customer' })),
//     phone: Type.Optional(Type.Integer({ description: 'Phone number of the customer' })),
//     courseId: Type.Optional(Type.String({ description: 'ID of the associated course' })),
//     course: Type.Optional(CourseResponse), // Directly reference the schema
// });

// // Post Customer Schema
// export const postCustomerSchema: FastifySchema = {
//     description: 'Create a new Customer',
//     summary: 'Creates a new Customer',
//     body: CustomerPayload, // Directly reference the schema
//     response: {
//         201: CustomerResponse, // Directly reference the schema
//     },
// };

// // Not Found Schema
// export const notFoundSchema = Type.Object({
//     statusCode: Type.Number({ description: 'HTTP status code', example: 404 }),
//     error: Type.String({ description: 'Error message', example: 'Not found' }),
//     message: Type.String({ description: 'Detailed error message', example: 'Customer record not found in database' }),
// });

// // Customer Params Schema
// const CustomerParams = Type.Object({
//     uuid: Type.String({ description: 'Customer ID' }),
// });

// // Get Customer by ID Schema
// export const getCustomerByIdSchema: FastifySchema = {
//     description: 'Gets a single Customer',
//     tags: ['Customer'],
//     summary: 'Gets Customer by Id',
//     params: CustomerParams, // Directly reference the schema
//     response: {
//         200: CustomerResponse, // Directly reference the schema
//         404: notFoundSchema,   // Directly reference the schema
//     },
// };

// // Type Export
// export type CustomerParamsType = Static<typeof CustomerParams>;
