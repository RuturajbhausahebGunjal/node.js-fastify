import { DataTypes, Model } from 'sequelize';
import sequelize from '@infrastructure/database';
import { StudentBaap } from '@core/entities/student.training.entity';
import CustomerModel from './customer.model';

class StudentModel extends Model<StudentBaap> { }

StudentModel.init(
    {
        uuid: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            allowNull: false,
            primaryKey: true,
        },
        name: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        email: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        password: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        phone: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        enrolled: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
        },
        // customer_id: {
        //     type: DataTypes.STRING,
        //     allowNull: false,
        //     references: {
        //         model: CustomerModel,
        //         key: "id",
        //     }
        // }
    },
    {
        sequelize,
        tableName: 'student',
        timestamps: true,
    }
);


// StudentModel.belongsTo(CustomerModel, { foreignKey: ' customer_id', as: "customer" });

export default StudentModel;