require('module-alias/register');
import { createServer } from '@infrastructure/http/server/server';
import { initDB } from '@infrastructure/database';

const main = async (): Promise<void> => {
    const server = await createServer();
    const { PORT: port, DATABASE_HOST: host } = process.env;

    await initDB();

    await server.listen({ host: host ?? '127.0.0.1', port: parseInt(port ?? '3000', 10) });
    process.on('unhandledRejection', (err) => {
        console.error(err);
        process.exit(1);
    });

    for (const signal of ['SIGINT', 'SIGTERM']) {
        process.on(signal, () => {
            console.log(`closing application on ${signal}`);
            server
                .close()
                .then(() => process.exit(0))
                .catch(() => process.exit(1));
        });
    }
};

void main();
