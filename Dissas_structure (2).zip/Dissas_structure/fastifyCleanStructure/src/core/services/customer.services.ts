import { CustomerPayload } from "@core/entities/customer.payload";
import { CustomerEntity } from "@core/entities/customer.entity";
import { ICustomerRepo } from "@core/repositories/customer.repository";

interface ICustomerService {
    createCustomer: (customerPayload: CustomerPayload) => Promise<CustomerEntity>;
    getCustomer: (uuid: string) => Promise<CustomerEntity | undefined>;
    getAllCustomer: () => Promise<CustomerEntity[]>;
    updateCustomer: (uuid: string, customerPayload: CustomerPayload) => Promise<CustomerEntity | undefined>;
    deleteCustomer: (uuid: string) => Promise<void>;
}

export const CustomerService = (customerRepository: ICustomerRepo): ICustomerService => ({
    createCustomer: async (customerPayload: CustomerPayload): Promise<CustomerEntity> => {
        return await customerRepository.createCustomer(customerPayload);
    },
    getCustomer: async (uuid: string): Promise<CustomerEntity | undefined> => {
        return await customerRepository.getCustomer(uuid);
    },
    getAllCustomer: async (): Promise<CustomerEntity[]> => {
        return await customerRepository.getAllCustomer();
    },
    updateCustomer: async (uuid: string, customerPayload: CustomerPayload): Promise<CustomerEntity | undefined> => {
        return await customerRepository.updateCustomer(uuid, customerPayload);
    },
    deleteCustomer: async (uuid: string): Promise<void> => {
        await customerRepository.deleteCustomer(uuid); 
    }
});
