import { CustomerPayload } from "@core/entities/customer.payload";
import { CustomerEntity } from "@core/entities/customer.entity";

export interface ICustomerRepo {
    createCustomer: (customerPayload: CustomerPayload) => Promise<CustomerEntity>;

    getCustomer: (uuid: string) => Promise<CustomerEntity | undefined>;
    getAllCustomer:()=>Promise<CustomerEntity[]>;
    updateCustomer(uuid: string, customerPayload: CustomerPayload): CustomerEntity | PromiseLike<CustomerEntity | undefined> | undefined;
    deleteCustomer(uuid: string): Promise<boolean>;
}






