import { StudentTrainingPayload } from '@core/entities/student.training.payload';
import { StudentBaap } from '@core/entities/student.training.entity';

export interface IStudentRepo {
    createStudent: (studentPayload: StudentTrainingPayload) => Promise<StudentBaap>;
    getStudent: (uuid: string) => Promise<StudentBaap | undefined>;
}

// export interface IStudentRepository {
//     createStudent: (studentPayload: StudentTrainingPayload) => Promise<StudentBaap>;
//     getStudent: (uuid: string) => Promise<StudentBaap | undefined>;
//     getAllStudent: () => Promise<StudentBaap[]>; // Retrieves all students
//     updateStudent: (uuid: string, studentPayload: Partial<StudentTrainingPayload>) => Promise<StudentBaap | undefined>; // Updates a student
//     deleteStudent: (uuid: string) => Promise<boolean>; // Deletes a student
// }