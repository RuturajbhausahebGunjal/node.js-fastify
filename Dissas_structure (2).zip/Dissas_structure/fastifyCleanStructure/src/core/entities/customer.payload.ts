import { CustomerEntity } from "@core/entities/customer.entity";

export type CustomerPayload = Omit<CustomerEntity, 'uuid'>;

