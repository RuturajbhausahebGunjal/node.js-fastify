import { StudentBaap } from '@core/entities/student.training.entity';

export type StudentTrainingPayload = Omit<StudentBaap, 'uuid'>;
