export interface baapCompanyInterface {
     id:string;
     companyName:string;
     founder:string;
     empolyees:string;
    
}