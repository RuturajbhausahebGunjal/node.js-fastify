export interface CourseInterface {
    id:string;
    name:string;
    email:string;
    password:string;
    city:string;
    is_enabled:boolean;
    is_deleted:boolean;
}

