export interface StudentInterface {
    id:string;
    name:string;
    email:string;
    password:string;
    age:string;
    course_id:string;
    is_enabled:boolean;
    is_deleted:boolean;
}
