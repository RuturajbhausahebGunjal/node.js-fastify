import { FastifyInstance } from "fastify";
import studentRoutes from "./student.routes";
import courseRpoutes from "./course.routes";
import baapCompanyRoutes from "./baapCompany.routes";

const basePrefix = "/baseApi";


export default async function (app: FastifyInstance) {
    app.register(studentRoutes, { prefix: `${basePrefix} /student` });
    app.register(courseRpoutes, { prefix: `${basePrefix} /course` });
    app.register(baapCompanyRoutes, { prefix: `${basePrefix} /baap` });

}