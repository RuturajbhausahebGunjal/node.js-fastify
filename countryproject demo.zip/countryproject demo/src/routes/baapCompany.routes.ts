import fastify, { FastifyInstance } from "fastify";


import {createCompanyInfo,getAllCompanies, getCompaniesbyId} from "../controller/baapCompany.Controller";

const baapCompanyRoutes = async (fastify:FastifyInstance)=>{
    fastify.post('/createCompanies',createCompanyInfo);
    fastify.get('/getAllCompanies',getAllCompanies),
    fastify.get('/getCompaniesbyId/:id',getCompaniesbyId)
}

export default baapCompanyRoutes;
