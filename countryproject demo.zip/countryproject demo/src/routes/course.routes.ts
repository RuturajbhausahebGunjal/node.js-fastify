import fastify,{FastifyInstance} from "fastify";

import {createCourse , getAllCourse,getCoursebyID, updateCourse, deleteCourse } from "../controller/courseController";


 const  courseRpoutes =async (fastify:FastifyInstance)=>{
    fastify.post('/createCourse',createCourse);
    fastify.get('/getAllCourse',getAllCourse);
    fastify.get('/getCourseID/:id',getCoursebyID);
    fastify.put('/updateCourse/:id',updateCourse);
    fastify.delete('/deleteCourse/:id',deleteCourse);
 } 

 export default courseRpoutes;

