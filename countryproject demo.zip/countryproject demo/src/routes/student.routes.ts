import fastify, { FastifyInstance } from "fastify";

import { createStudent, deleteStudent, getAllStudent, getStudentbyID, updateStudent } from "../controller/studentContoller";


const studentRoutes = async (fastify: FastifyInstance) => {
   fastify.post('/createStudent', createStudent);
   fastify.get('/getAllStudent', getAllStudent);
   fastify.get('/getStudentID/:id', getStudentbyID);
   fastify.put('/updateStudent/:id', updateStudent);
   fastify.delete('/deleteStudent/:id', deleteStudent);
}

export default studentRoutes;