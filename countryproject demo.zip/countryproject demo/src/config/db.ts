import dotenv from "dotenv";
import logger from "../plugins/logger";

dotenv.config();

export const config = {
    database: {
        host: process.env.DATABASE_HOST,
        user: process.env.DATABASE_USERNAME,
        password: process.env.DATABASE_PASSWORD,
        name: process.env.DATABASE_NAME,
        dialect: 'mysql', 
        port: Number(process.env.DB_PORT) || 3306, 
      
    }
};
