import baapcompanyModel from "../model/baapCompany.model";
import { baapCompanyInterface } from "../interfaces/baapcompany.interface";
import { FastifyInstance, FastifyReply, FastifyRequest } from "fastify";




export const createCompanyInfo = async (request: FastifyRequest, reply: FastifyReply) => {
    try {

        const companyData = request.body as baapCompanyInterface[];

        if (!Array.isArray(companyData) || companyData.length === 0) {
            return reply.status(400).send({
                status_code: 400,
                message: 'Invalid Input',
            });
        }
        const formattedData = companyData.map((company) => {

            return {
                companyName: company.companyName,
                founder: company.founder,
                empolyees: company.empolyees
            };
        });
 
        const Companies = await baapcompanyModel.bulkCreate(formattedData);

        reply.status(201).send({
            status_code: 201,
            message: 'Companies created successfully',
            data: Companies,
        });
    } catch (error) {
        reply.status(500).send({
            status_code: 500,
            message: 'An error occurred while creating companies',
            error: (error as Error).message,
        });
    }
};


export const getAllCompanies = async (request: FastifyRequest, reply: FastifyReply) => {
    try {
        const CompaniesAllData = await baapcompanyModel.findAll();

        reply.status(201).send({
            status_code: 200,
            data: CompaniesAllData
        });
    } catch (error) {
        reply.status(500).send({
            message: 'Error fetching CourseData'
        });
    }
}


export const getCompaniesbyId = async (request: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) => {

    const { id } = request.params as { id: string };

    try {

        const courseID = await baapcompanyModel.findByPk(id);
        if (!courseID) {
            reply.status(404).send({
                status_code: 404,
                message: 'Company Not Found'
            });

        }
        reply.status(200).send({
            status_code: 200,
            message: 'Company retreived successfully',
            data: courseID
        })

    } catch (error) {
        reply.status(500).send({
            status_code: 500,
            message: "Failed to fetch Company",
        });

    }
}


export const updatecompany = async (
    request: FastifyRequest<{
        Params: { id: string };
        Body: Partial<baapCompanyInterface>;
    }>,
    reply: FastifyReply
) => {
    const { id } = request.params;
    const updateCompany = request.body;

    try {
        const [updatedRows] = await baapcompanyModel.update(
            { ...updateCompany, modified_on: new Date() },
            { where: { id } }
        );

        if (updatedRows > 0) {
            reply.status(200).send({
                status_code: 200,
                message: "Company updated successfully",
                id: id

            });
        } else {
            reply.status(404).send({
                status_code: 404,
                message: "Company not found",
                state: [],

            });
        }
    } catch (error) {
        reply.status(500).send({
            status_code: 500,
            message: "Failed to update Company",
            error,
        });
    }
};

export async function deleteCourse(
    request: FastifyRequest,
    reply: FastifyReply
) {

    try {
        const { id } = request.params as { id: string };
        const CourseLocum = await baapcompanyModel.findOne({ where: { id } });

        if (CourseLocum) {
            await baapcompanyModel.update({ is_deleted: true }, { where: { id } });

            return reply.status(200).send({
                status_code: 200,
                message: "Company deleted successfully",

            });

        } else {
            return reply.status(404).send({
                status_code: 404,
                message: "Company not found",

            });
        }
    } catch (error) {
        return reply.status(500).send({
            status_code: 500,
            message: "Failed to delete Company",
            error,
        });
    }
}


