import StudentModel from "../model/student.model";
import { StudentInterface } from "../interfaces/student.interface";
import { FastifyInstance, FastifyReply, FastifyRequest } from "fastify";
import CourseModel from "../model/course.model";


export const createStudent = async (request: FastifyRequest, reply: FastifyReply) => {

  try {
    const studentData = request.body as StudentInterface;
    const student = await StudentModel.create({
      ...studentData
    });
    reply.status(201).send({
      status_code: 200,
      message: 'student create Successfully',
      data: student
    });


  } catch (error) {
    reply.status(500).send({
      status_code: 500,
      error: (error as Error).message,
      message: "internal server error",
    })
  }

}


export const getAllStudent = async (request: FastifyRequest, reply: FastifyReply) => {

  try {
    const studentAllData = await StudentModel.findAll({
      include: [
        {
          model: CourseModel,
          as: 'course'
        }
      ],
      where: { is_deleted: false }
    });

    reply.status(200).send({
      status_code: 200,
      data: studentAllData
    });
  } catch (error) {
    reply.status(500).send({
      message: 'Error fetching StudentData',
      error: (error as Error).message
    });
  }
}


export const getStudentbyID = async (request: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) => {

  const { id } = request.params as { id: string };

  try {

    const studentID = await StudentModel.findByPk(id);
    if (!studentID) {
      reply.status(404).send({
        status_code: 404,
        message: 'student Not Found'
      });

    }
    reply.status(200).send({
      status_code: 200,
      message: 'Student retreived successfully',
      data: studentID
    })

  } catch (error) {
    reply.status(500).send({
      status_code: 500,
      message: "Failed to fetch State",
    });

  }
}

export const updateStudent = async (
  request: FastifyRequest<{
    Params: { id: string };
    Body: Partial<StudentInterface>;
  }>,
  reply: FastifyReply
) => {
  const { id } = request.params;
  const updateStudent = request.body;

  try {
    const [updatedRows] = await StudentModel.update(
      { ...updateStudent, modified_on: new Date() },
      { where: { id } }
    );

    if (updatedRows > 0) {
      reply.status(200).send({
        status_code: 200,
        message: "update updated successfully",
        id: id

      });
    } else {
      reply.status(404).send({
        status_code: 404,
        message: "Student not found",
        state: [],

      });
    }
  } catch (error) {
    reply.status(500).send({
      status_code: 500,
      message: "Failed to update Student",
      error,
    });
  }
};

export async function deleteStudent(
  request: FastifyRequest,
  reply: FastifyReply
) {

  try {
    const { id } = request.params as { id: string };
    const candidateLocum = await StudentModel.findOne({ where: { id } });

    if (candidateLocum) {
      await StudentModel.update({ is_deleted: true }, { where: { id } });

      return reply.status(200).send({
        status_code: 200,
        message: "Student deleted successfully",

      });

    } else {
      return reply.status(404).send({
        status_code: 404,
        message: "Student not found",

      });
    }
  } catch (error) {
    return reply.status(500).send({
      status_code: 500,
      message: "Failed to delete Student",
      error,
    });
  }
}


