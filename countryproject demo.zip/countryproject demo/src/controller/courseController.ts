import { CourseInterface } from "../interfaces/course.interface";
import { FastifyInstance, FastifyReply, FastifyRequest } from "fastify";
import CourseModel from "../model/course.model";


export const createCourse = async (request: FastifyRequest, reply: FastifyReply) => {

  try {
    const courseData = request.body as CourseInterface;
    const course = await CourseModel.create({
      ...courseData
    });

    reply.status(201).send({
      status_code: 200,
      message: 'course create Successfully',
      data: course
    });


  } catch (error) {
    reply.status(500).send({
      status_code: 500,
      error: (error as Error).message,
      message: "internal server error",
    })
  }

}


export const getAllCourse = async (request: FastifyRequest, reply: FastifyReply) => {
  try {
    const CourseAllData = await CourseModel.findAll({

    });

    reply.status(201).send({
      status_code: 200,
      data: CourseAllData
    });
  } catch (error) {
    reply.status(500).send({
      message: 'Error fetching CourseData'
    });
  }
}


export const getCoursebyID = async (request: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) => {

  const { id } = request.params as { id: string };

  try {

    const courseID = await CourseModel.findByPk(id);
    if (!courseID) {
      reply.status(404).send({
        status_code: 404,
        message: 'course Not Found'
      });

    }
    reply.status(200).send({
      status_code: 200,
      message: 'course retreived successfully',
      data: courseID
    })

  } catch (error) {
    reply.status(500).send({
      status_code: 500,
      message: "Failed to fetch Company",
    });

  }
}

export const updateCourse  = async (
  request: FastifyRequest<{
    Params: { id: string };
    Body: Partial<CourseInterface>;
  }>,
  reply: FastifyReply
) => {
  const { id } = request.params;
  const updateCourse = request.body;

  try {
    const [updatedRows] = await CourseModel.update(
      { ...updateCourse, modified_on: new Date() },
      { where: { id } }
    );

    if (updatedRows > 0) {
      reply.status(200).send({
        status_code: 200,
        message: "Course updated successfully",
        id: id

      });
    } else {
      reply.status(404).send({
        status_code: 404,
        message: "Course not found",
        state: [],

      });
    }
  } catch (error) {
    reply.status(500).send({
      status_code: 500,
      message: "Failed to update Course",
      error,
    });
  }
};

export async function deleteCourse (
  request: FastifyRequest,
  reply: FastifyReply
) {

  try {
    const { id } = request.params as { id: string };
    const CourseLocum = await CourseModel.findOne({ where: { id } });

    if (CourseLocum) {
      await CourseModel.update({ is_deleted: true }, { where: { id } });

      return reply.status(200).send({
        status_code: 200,
        message: "Course deleted successfully",

      });

    } else {
      return reply.status(404).send({
        status_code: 404,
        message: "Course not found",

      });
    }
  } catch (error) {
    return reply.status(500).send({
      status_code: 500,
      message: "Failed to delete Course",
      error,
    });
  }
}


