import { DataType, DataTypes, Model, UUIDV4 } from "sequelize";
import { sequelize } from "../plugins/sequelize";
import { StudentInterface } from "../interfaces/student.interface";
import CourseModel from "./course.model";


class StudentModel extends Model { }

StudentModel.init({
    id: {
        type: DataTypes.UUID,
        defaultValue: UUIDV4,
        allowNull: false,
        primaryKey: true,
    },

    name: {
        type: DataTypes.STRING(255),
        allowNull: false,

    },
    email: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
    password: {
        type: DataTypes.STRING(255),
        allowNull: false

    },
    age: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
    course_id: {
        type: DataTypes.UUID,
        allowNull: false,
        references: {
            model: CourseModel,
            key: "id",
        },
    },
    is_enabled: {
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: true,
    },
    is_deleted: {
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: false,
    },
},
    {
        sequelize,
        tableName: 'student',
        timestamps: false

    }
);


StudentModel.belongsTo(CourseModel, { foreignKey: 'course_id', as: 'course' })

export default StudentModel; 