import { DataType, DataTypes, Model } from "sequelize";
import { sequelize } from "../plugins/sequelize";
import { CourseInterface } from "../interfaces/course.interface";


class CourseModel extends Model { }

CourseModel.init({
    id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        primaryKey: true,

    },
    name: {
        type: DataTypes.STRING,
        allowNull: false,

    },
    email: {
        type: DataTypes.STRING,
        allowNull: false
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false

    },
    city: {
        type: DataTypes.STRING,
        allowNull: false
    },
    is_enabled: {
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: true,
    },
    is_deleted: {
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: false,
    },
},
    {
        sequelize,
      
         tableName:'course',
         timestamps:true
    }
);


export default CourseModel;