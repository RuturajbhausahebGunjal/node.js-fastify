import { IStudentRepository } from "@core/repositories/student.repo";
import { StudentTrainingPayload } from "@core/entities/StudentTrainingPayload";
import { StudentBaap } from "@core/entities/student";
import StudentModel from "@infrastructure/database/models/student.model";
import TeacherModel from "@infrastructure/database/models/teacher.model";

export class StudentRepository implements IStudentRepository {
    getStudentById(id: string): StudentBaap | PromiseLike<StudentBaap | undefined> | undefined {
        throw new Error("Method not implemented.");
    }
    // Assuming method is yet to be implemented
    getStudentWithTeacher(id: string): unknown {
        throw new Error("Method not implemented.");
    }

    // Creating a new student
    async createStudent(studentPayload: StudentTrainingPayload): Promise<StudentBaap> {
        try {
            const student = await StudentModel.create(studentPayload);
            return student.toJSON() as StudentBaap;  // Use toJSON() to return plain object
        } catch (error) {
            // Handle the error or log it accordingly
            throw new Error("Error creating student: " + error);
        }
    }

    // Fetching student by ID with associated teacher data
    // async getStudentById(id: string): Promise<StudentBaap | undefined> {
    //     try {
    //         const student = await StudentModel.findByPk(id, {
    //             include: [{
    //                 model: TeacherModel,
    //                 as: "teacher",  // Adjust alias as per your Sequelize model
    //             }],
    //         });

    //         return student ? (student.toJSON() as StudentBaap) : undefined;  // Return plain object
    //     } catch (error) {
    //         // Handle errors such as database connectivity issues
    //         throw new Error("Error fetching student: " + error);
    //     }
    // }

    // Fetching all students
    async getAllStudents(): Promise<StudentBaap[]> {
        try {
            const students = await StudentModel.findAll({
                include: [
                    {
                        model: TeacherModel,
                        as: "teachers", 
                    },
                ],
            });

            return students.map(student => student.toJSON() as StudentBaap);
        } catch (error) {
            console.error("Error in StudentRepository.getAllStudents:", error);
            throw new Error("Error fetching all students: " + error);
        }
    }

    // Updating student details
    async updateStudent(id: string, studentPayload: StudentTrainingPayload): Promise<StudentBaap | undefined> {
        try {
            const student = await StudentModel.findByPk(id);
            if (!student) {
                // Student not found, throw error or return undefined
                throw new Error("Student not found");
            }

            await student.update(studentPayload);
            return student.toJSON() as StudentBaap;  // Return updated student as plain object
        } catch (error) {
            // Handle any error that occurs during the update
            throw new Error("Error updating student: " + error);
        }
    }

    // Deleting student by ID
    async deleteStudent(id: string): Promise<boolean> {
        try {
            const student = await StudentModel.findByPk(id);
            if (!student) {
                // Student not found
                return false; 
            }
            await student.destroy();  // Destroying the student record
            return true;  // Deletion successful
        } catch (error) {
            // Handle errors like database connectivity issues
            throw new Error("Error deleting student: " + error);
        }
    }
}
