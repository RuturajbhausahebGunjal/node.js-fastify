import TeacherModel from "@infrastructure/database/models/teacher.model";
import StudentModel from "@infrastructure/database/models/student.model";

export const defineAssociations = () => {
    StudentModel.belongsTo(TeacherModel, { as: "teachers", foreignKey: "teacherId" });
    TeacherModel.hasMany(StudentModel, { as: "student_data", foreignKey: "teacherId" });
    
};