
export const createTeacherSchema = {
    body: {
        type: 'object',
        required: ['email', 'phone', 'subject'],
        properties: {
            name: { type: 'string', minLength: 1 },
            email: { type: 'string', format: 'email' },
            phone: { type: 'integer', minimum: 1000000000, maximum: 9999999999 },
            subject: { type: 'string', minLength: 1 },
            date_of_joining: { type: 'string', format: 'date-time' },
            is_active: { type: 'boolean' }
        },
        additionalProperties: false
    }
};

export const getAllTeachersSchema = {
    response: {
        200: {
            type: 'array',
            items: {
                type: 'object',
                properties: {
                    uuid: { type: 'string', format: 'uuid' },
                    name: { type: 'string' },
                    email: { type: 'string', format: 'email' },
                    phone: { type: 'integer' },
                    subject: { type: 'string' },
                    date_of_joining: { type: 'string', format: 'date-time' },
                    is_active: { type: 'boolean' }
                }
            }
        },

    },

};

export const updateTeacherSchema = {
    params: {
        type: 'object',
        required: ['id'],
        properties: {
            id: { type: 'string', format: 'uuid' }
        }
    },
    body: {
        type: 'object',
        properties: {
            name: { type: 'string', minLength: 1 },
            email: { type: 'string', format: 'email' },
            phone: { type: 'integer', minimum: 1000000000, maximum: 9999999999 },
            subject: { type: 'string', minLength: 1 },
            date_of_joining: { type: 'string', format: 'date-time' },
            is_active: { type: 'boolean' }
        },
        additionalProperties: false
    }
};

export const deleteTeacherSchema = {
    params: {
        type: 'object',
        required: ['id'],
        properties: {
            id: { type: 'string', format: 'uuid' }
        }
    }
};
