import { FastifySchema } from "fastify";
import { Static, Type } from "@sinclair/typebox";

// Define the payload schema for creating a new student
export const StudentPayload = Type.Object({
    name: Type.String(),
    email: Type.String(),
    password: Type.String(),
    phone: Type.Integer(),
    enrolled: Type.Boolean(),
    teacherId: Type.String()
});

// Define the response schema for student
export const StudentResponse = Type.Object({
    uuid: Type.String(),  // uuid is typically required for the response
    name: Type.String(),
    email: Type.String(),
    password: Type.String(),
    phone: Type.Integer(),
    enrolled: Type.Boolean(),
    teacherId: Type.String(),
});

// Schema for creating a new student (POST request)
export const postStudentSchema: FastifySchema = {
    description: 'Create a new Student',
    summary: 'Creates a new student',
    body: StudentPayload,
    response: {
        201: { ...StudentResponse, description: 'Success' },
    },
};

// Not found schema for 404 errors
export const notFoundSchema = Type.Object({
    statusCode: Type.Number({ example: 404 }),
    error: Type.String({ example: 'Not found' }),
    message: Type.String({ example: 'Student record not found in database' })
});

// Params schema for identifying a student by uuid
const StudentParams = Type.Object({
    uuid: Type.String({ description: 'Student Id' }),
});

// Params schema for identifying a student by teacherId
const StudentParams1 = Type.Object({
    teacherId: Type.String({ description: 'Teacher Id' }),
});

// Schema for getting students by teacherId (GET request)
export const getStudentByID: FastifySchema = {
    description: 'Gets all students for a teacher',
    tags: ['Student'],
    summary: 'Gets students by teacherId',
    params: StudentParams1,
    response: {
        200: Type.Array(StudentResponse),  // Return array of students
        404: { ...notFoundSchema, description: 'Not found' },
    },
};

// Schema for getting all students (GET request)
export const getAllStudentsSchema: FastifySchema = {
    description: 'Get all Students',
    summary: 'Fetch all student records',
    response: {
        200: Type.Array(StudentResponse),  // Return array of students
    },
};

// Schema for deleting a student (DELETE request)
export const deleteStudentSchema: FastifySchema = {
    description: 'Delete a Student',
    summary: 'Delete student by Id',
    params: StudentParams,
    response: {
        200: {
            type: 'object',
            properties: {
                message: { type: 'string', example: 'Student deleted successfully' },
            },
        },
        404: { ...notFoundSchema, description: 'Student not found' },
    },
};

// Schema for updating a student (PUT request)
export const updateStudentSchema: FastifySchema = {
    description: 'Update a Student',
    summary: 'Update student details by Id',
    params: StudentParams,
    body: StudentPayload,
    response: {
        200: { ...StudentResponse, description: 'Student updated successfully' },
        404: { ...notFoundSchema, description: 'Student not found' },
    },
};

// Type for StudentParams (e.g., uuid for a student)
export type StudentParamsType = Static<typeof StudentParams>;
// Type for StudentParams1 (e.g., teacherId for students)
export type StudentParams1Type = Static<typeof StudentParams1>;
