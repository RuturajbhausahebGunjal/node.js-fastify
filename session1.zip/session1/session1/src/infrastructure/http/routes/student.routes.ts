import { type RouteOptions } from 'fastify'
import {
    createStudent,
    getAllStudents,
    updateStudent,
    deleteStudent,
} from '@infrastructure/http/controllers/students.ctrl'
import { type IStudentRepository } from '@core/repositories/student.repo'
import { getAllStudentsSchema, getStudentByID, postStudentSchema } from '../schemas/studentSchema'

export const studentRoutes = (studentRepository: IStudentRepository): RouteOptions[] => ([
    {
        method: 'POST',
        url: '/studentUser',
        handler: createStudent(studentRepository),
    },
    {
        method: 'GET',
        url: '/getAllStudents',
        handler: getAllStudents(studentRepository),
    },
    // Uncomment if you want to get student by UUID
    // {
    //     method: 'GET',
    //     url: '/studentUser/:id',
    //     handler: getStudentById(studentRepository),
    //     schema:getStudentByID
    // },
    {
        method: 'PUT',
        url: '/studentUser/:id',
        handler: updateStudent(studentRepository),
    },
    {
        method: 'DELETE',
        url: '/studentUser/:id',
        handler: deleteStudent(studentRepository),
    },
    // New route to get student along with teacher data
    // {
    //     method: 'GET',
    //     url: '/studentUser/:id/teacher', // Path to fetch student and teacher info
    //     handler: getStudentWithTeacher(studentRepository),
    // }
])
