import { type RouteOptions } from 'fastify';
import {
    createTeacher,
    getAllTeachers,
    updateTeacher,
    deleteTeacher
} from '@infrastructure/http/controllers/teacher.ctrl';
import { type ITeacherRepository } from '@core/repositories/teacher.repo';

import { 
    createTeacherSchema, 
    getAllTeachersSchema, 
    updateTeacherSchema, 
    deleteTeacherSchema 
} from '@infrastructure/http/schemas/teacherSchemas';

export const teacherRoutes = (teacherRepository: ITeacherRepository): RouteOptions[] => ([
    {
        method: 'POST',
        url: '/Teacher',
        handler: createTeacher(teacherRepository),
        schema: createTeacherSchema 
    },
    {
        method: 'GET',
        url: '/Teachers', 
        handler: getAllTeachers(teacherRepository),
        schema: getAllTeachersSchema 
    },
    {
        method: 'PUT',
        url: '/Teacher/:id',
        handler: updateTeacher(teacherRepository),
        schema: updateTeacherSchema 
    },
    {
        method: 'DELETE',
        url: '/Teacher/:id', 
        handler: deleteTeacher(teacherRepository),
        schema: deleteTeacherSchema 
    }
]);
