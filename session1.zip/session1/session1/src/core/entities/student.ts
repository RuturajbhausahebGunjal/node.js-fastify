export interface StudentBaap {
    uuid?: string;
    name?: string;
    email?: string;
    phone?: number;
    password?: string;
    enrolled?: boolean;
    teacherId: string;
}