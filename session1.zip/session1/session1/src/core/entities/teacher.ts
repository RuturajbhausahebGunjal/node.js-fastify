export interface Teacher {
    uuid: string;
    name?: string;
    email: string;
    phone: number;
    subject: string;
    date_of_joining?: string;
    is_active?: boolean;

}