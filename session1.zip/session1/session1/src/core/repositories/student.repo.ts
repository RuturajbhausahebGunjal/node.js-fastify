import { StudentTrainingPayload } from "../entities/StudentTrainingPayload";
import { StudentBaap } from "../entities/student";

export interface IStudentRepository {
    getStudentById(id: string): StudentBaap | PromiseLike<StudentBaap | undefined> | undefined;
    createStudent(studentPayload: StudentTrainingPayload): Promise<StudentBaap>;  // Create a new student
    getAllStudents(): Promise<StudentBaap[]>;  // Get all students along with teacher data
    updateStudent(id: string, studentPayload: StudentTrainingPayload): Promise<StudentBaap | undefined>;  // Update a student
    deleteStudent(id: string): Promise<boolean>;  // Delete a student by ID
}
