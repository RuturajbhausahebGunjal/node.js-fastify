import { StudentTrainingPayload } from "../entities/StudentTrainingPayload";
import { StudentBaap } from "../entities/student";
import { IStudentRepository } from "../repositories/student.repo";

// Define the interface for the service
interface IStudentService {
    getStudentById(id: string): Promise<StudentBaap | undefined>; // Ensure it returns a Promise with the student or undefined
    createStudent(studentTrainingPayload: StudentTrainingPayload): Promise<StudentBaap>; // Ensure return type is a Promise
    getAllStudents(): Promise<StudentBaap[]>; // Returns a Promise with an array of StudentBaap
}

// Service Implementation
export const StudentService = (
    studentRepository: IStudentRepository
): IStudentService => ({
    createStudent: async (studentPayload: StudentTrainingPayload): Promise<StudentBaap> => {
        try {
            return await studentRepository.createStudent(studentPayload); // Ensure that this returns a Promise of StudentBaap
        } catch (error) {
            throw new Error(`Error creating student: ${error}`);
        }
    },
    getAllStudents: async (): Promise<StudentBaap[]> => {
        try {
            return await studentRepository.getAllStudents(); // Ensure that this returns a Promise of StudentBaap array
        } catch (error) {
            throw new Error(`Error fetching students: ${error}`);
        }
    },
    getStudentById: async (id: string): Promise<StudentBaap | undefined> => {
        try {
            return await studentRepository.getStudentById(id); // Ensure that this method exists in the repository
        } catch (error) {
            throw new Error(`Error fetching student by ID: ${error}`);
        }
    }
});
