import { StudentTrainingPayload } from '@core/entities/student.training.payload';
import { StudentBaap } from '@core/entities/student.training.entity';

export interface IStudentRepo {
    createStudent: (studentPayload: StudentTrainingPayload) => Promise<StudentBaap>;
    getStudent: (uuid: string) => Promise<StudentBaap | undefined>;
}
