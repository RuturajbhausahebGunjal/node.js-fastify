import { CustomerPayload } from "@core/entities/customer.payload";
import { CustomerEntity } from "@core/entities/customer.entity";

export interface ICustomerRepo {
    createCustomer: (customerPayload: CustomerPayload) => Promise<CustomerEntity>;
    getCustomer: (uuid: string) => Promise<CustomerEntity | undefined>;
}