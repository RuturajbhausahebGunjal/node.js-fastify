import { CustomerPayload } from "@core/entities/customer.payload";
import { CustomerEntity } from "@core/entities/customer.entity";
import { ICustomerRepo } from "@core/repositories/customer.repository";

interface ICustomerService {
    createCustomer: (customerPayload: CustomerPayload) => Promise<CustomerEntity>;
    getCustomer: (uuid: string) => Promise<CustomerEntity | undefined>;
}

export const CustomerService = ( customerRepository: ICustomerRepo): ICustomerService => (
    {
        createCustomer: async (customerPayload: CustomerPayload): Promise<CustomerEntity> => {
            return await customerRepository.createCustomer(customerPayload);
        },
        getCustomer: async (uuid: string): Promise<CustomerEntity | undefined> => {
            return await customerRepository.getCustomer(uuid);
        }
    }
);