import { StudentTrainingPayload } from '@core/entities/student.training.payload';
import { StudentBaap } from '@core/entities/student.training.entity';
import { IStudentRepo } from '@core/repositories/student.repository';

interface IStudentService {
    createStudent: (studentTrainingPayload: StudentTrainingPayload) => Promise<StudentBaap>;
    getStudent: (uuid: string) => Promise<StudentBaap | undefined>;
}

export const StudentService = (
    studentRepository: IStudentRepo
): IStudentService => ({
    createStudent: async (studentPayload: StudentTrainingPayload): Promise<StudentBaap> => {
        return await studentRepository.createStudent(studentPayload);
    },
    getStudent: async (uuid: string): Promise<StudentBaap | undefined> => {
        return await studentRepository.getStudent(uuid);
    }
});
