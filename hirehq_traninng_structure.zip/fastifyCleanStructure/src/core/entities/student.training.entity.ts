export interface StudentBaap {
    uuid?: string;
    name?: string;
    email?: string;
    phone?: string;
    password?: string;
    enrolled?: string;
}
