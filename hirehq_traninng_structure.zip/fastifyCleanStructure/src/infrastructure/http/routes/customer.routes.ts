import { RouteOptions } from "fastify";
import { createCustomer } from "../controller/customer.controller";
import { ICustomerRepo } from "@core/repositories/customer.repository";

export const customerRoutes = (customerRepository: ICustomerRepo): RouteOptions[] => [
    {
        method: 'POST',
        url: '/create/customer',
        handler: createCustomer(customerRepository),
    }
]

