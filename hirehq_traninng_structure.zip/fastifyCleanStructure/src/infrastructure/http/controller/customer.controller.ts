import type { ICustomerRepo } from "@core/repositories/customer.repository";
import type { FastifyRequest, FastifyReply } from "fastify";
import { CustomerService } from "@core/services/customer.services";
import type { CustomerPayload } from "@core/entities/customer.payload";


export const createCustomer = (
    customerRepository: ICustomerRepo
) => 
    async function (request: FastifyRequest, reply: FastifyReply) {
        const customer = await CustomerService(customerRepository).createCustomer(request.body as CustomerPayload);
        void reply.status(201).send(customer);
    }

// export const getCustomer = (
//     customerRepository: ICustomerRepo 
// ) => 
//     async function (request: FastifyRequest, reply: FastifyReply) {
//         const customer = await CustomerService(customerRepository).getCustomer(request.params as )
//     }
