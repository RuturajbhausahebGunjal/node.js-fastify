import type {IStudentRepo} from "@core/repositories/student.repository";
import type {FastifyReply, FastifyRequest} from "fastify";
import {StudentService} from "@core/services/student.services";
import type { StudentTrainingPayload } from '@core/entities/student.training.payload';


export const createStudent = (
    studentRepository: IStudentRepo
) => async function (request: FastifyRequest, reply: FastifyReply) {
    const student = await StudentService(studentRepository)
        .createStudent(request.body as StudentTrainingPayload);
    void reply.status(201).send(student);
}