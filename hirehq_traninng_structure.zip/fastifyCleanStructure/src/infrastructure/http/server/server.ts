import fastify, { FastifyInstance, FastifyServerOptions } from 'fastify';
import { TypeBoxTypeProvider } from '@fastify/type-provider-typebox';
import routes from '@infrastructure/http/routes';
import cors from '@fastify/cors';

import sequelize from '@infrastructure/database';
import { StudentRepository } from '@infrastructure/repositories/student.repositories';
import { CustomerRepository } from '@infrastructure/repositories/customer.repositories'; // Already imported

export const createServer = async (): Promise<FastifyInstance> => {
    const envToLogger: any = {
        development: {
            transport: {
                target: 'pino-pretty',
                options: {
                    translateTime: 'HH:MM:ss Z',
                    ignore: 'pid,hostname',
                },
            },
        },
        production: true,
        test: false,
    };

    const environment = process.env.NODE_ENV ?? 'production';
    await sequelize.sync();
    const serverOptions: FastifyServerOptions = {
        ajv: {
            customOptions: {
                removeAdditional: 'all',
                coerceTypes: true,
                useDefaults: true,
                keywords: ['kind', 'modifier'],
            },
        },
        logger: envToLogger[environment] ?? true,
    };

    const server = fastify(serverOptions).withTypeProvider<TypeBoxTypeProvider>();

    server.register(cors, {
        origin: '*',
        methods: ['GET', 'POST', 'PUT', 'DELETE'],
        allowedHeaders: ['Content-Type', 'Authorization'],
    });

    server.get('/', async (request, reply) => {
        reply.send({ message: 'Welcome to the TEAI service' });
    });

    // Instantiate repositories
    const studentRepository = new StudentRepository();
    const customerRepository = new CustomerRepository(); // Add CustomerRepository

    // Pass both repositories to routes
    const applicationRoutes = routes(studentRepository, customerRepository);
    applicationRoutes.forEach((route) => {
        server.route(route);
    });

    await server.ready();
    return server;
};
