import { ICustomerRepo } from "@core/repositories/customer.repository";
import { CustomerPayload } from "@core/entities/customer.payload";
import { CustomerEntity } from "@core/entities/customer.entity";
import CustomerModel from "@infrastructure/database/models/customer.model";


export class CustomerRepository implements ICustomerRepo {
    async createCustomer(customerPayload: CustomerPayload): Promise<CustomerEntity> {
        const customer = await CustomerModel.create(customerPayload); // ORM
        return customer as CustomerEntity;
    }

    async getCustomer(uuid: string): Promise<CustomerEntity | undefined> {
        const customer = await CustomerModel.findByPk(uuid);
        return customer ? (customer as CustomerEntity) : undefined
    }
}

