import { DataTypes, Model } from 'sequelize';
import sequelize from '@infrastructure/database';
import { StudentBaap } from '@core/entities/student.training.entity';

class StudentModel extends Model<StudentBaap> {}

StudentModel.init(
    {
        uuid: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            allowNull: false,
            primaryKey: true,
        },
        name: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        email: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        password: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        phone: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        enrolled: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
        }
    },
    {
        sequelize,
        tableName: 'student',
        timestamps: true,
    }
);

export default StudentModel;
