import { FastifyRequest, FastifyReply } from "fastify";
import ExpenseConfigurationModel from "../models/expense-configuration.model";
import generateCustomUUID from "../utility/genrateTraceId";
import { baseSearch } from "../utility/baseService";
import { ExpenseConfigurationAttributes } from "../interfaces/expense-configuration.interfaces";
import ExpenseType from "../models/expense-type.model";

export async function getExpenseConfigurations(request: FastifyRequest, reply: FastifyReply) {
    const searchFields = ['id', 'status', 'program_id', 'is_expense'];
    const responseFields = ['id', 'config_name', 'status', 'program_id', 'is_expense', 'hierarchy', 'expense_start_date', 'week_end_day'];
    return baseSearch(request, reply, ExpenseConfigurationModel, searchFields, responseFields);
}

export async function getExpenseConfigurationById(request: FastifyRequest, reply: FastifyReply) {
    const traceId=generateCustomUUID();
    try {
        const { program_id, id } = request.params as { program_id: string, id: string };
        const expenseConfig = await ExpenseConfigurationModel.findOne({ where: { program_id, id } });
        
        if (expenseConfig) {
            reply.status(200).send({
                status_code: 200,
                message: 'Expense configuration fetched successfully.',
                trace_id:traceId,
                expense_config: expenseConfig
            });
        } else {
            reply.status(404).send({
                status_code: 404,
                message: 'Expense configuration not found.',
                expense_config:[],
                trace_id:traceId,
            });
        }
    } catch (error) {
        reply.status(500).send({
            message: 'An error occurred while fetching expense configuration.',
            trace_id:traceId,
        });
    }
}

export async function createExpenseConfiguration(request: FastifyRequest, reply: FastifyReply) {
    const { program_id } = request.params as { program_id: string };
    const traceId=generateCustomUUID();
    
    try {

    const expenseConfig: ExpenseConfigurationAttributes  = request.body as ExpenseConfigurationAttributes;

        const expenseConfigData = await ExpenseConfigurationModel.create({ ...expenseConfig, program_id });
        if (Array.isArray(expenseConfig.expense_type) && expenseConfig.expense_type.length > 0) {
            for (const expenseType of expenseConfig.expense_type) {
                await ExpenseType.create({
                    program_id,
                    expense_type: expenseType.expense_type,
                    expense_code: expenseType.expense_code,
                    expense_name: expenseType.expense_name,
                    expense_icon: expenseType.expense_icon,
                    attachment_mandatory: expenseType.attachment_mandatory,
                    notes_mandatory: expenseType.notes_mandatory,
                    msp_applicable: expenseType.msp_applicable,
                    status: expenseType.status,
                    unit_base: expenseType.unit_base,
                    unit_base_config: expenseType.unit_base_config,
                    created_on: new Date(),
                    modified_on: new Date(),
                });
            }
        }



        reply.status(201).send({
            status_code: 201,
           trace_id:traceId,
            id: expenseConfigData.id,
            message: 'Expense configuration created successfully.'
        });
    } catch (error) {
        reply.status(500).send({
            status_code: 500,
            message: 'An error occurred while creating expense configuration.',
            trace_id:traceId,
        });
    }
}
export async function updateExpenseConfiguration(
    request: FastifyRequest<{ Params: { id: string; program_id: string } }>,
    reply: FastifyReply
  ) {
    const traceId=generateCustomUUID();
    try {
      const { id, program_id } = request.params;
      const expenseConfigData = request.body as ExpenseConfigurationAttributes;
      const [rowUpdated] = await ExpenseConfigurationModel.update(
        { ...expenseConfigData },
        { where: { id, program_id } }
      );
  
      if (rowUpdated > 0) {
        reply.status(201).send({
          status_code: 201,
          message: 'Expense configuration updated successfully.',
          trace_id:traceId,
        });
      } else {
        reply.status(404).send({
          message: 'Expense configuration not found..',
          expense_config:[],
          trace_id:traceId,
        });
      }
    } catch (error) {
      reply.status(500).send({
        message: 'Internal Server error.',
        error,
        trace_id:traceId,
      });
    }
  }
  

export async function deleteExpenseConfiguration(request: FastifyRequest, reply: FastifyReply) {
    const traceId=generateCustomUUID();
    const { program_id, id } = request.params as { program_id: string, id: string };
    
    try {
        const [updatedCount] = await ExpenseConfigurationModel.update(
            { is_deleted: true, is_enabled: false },
            { where: { program_id, id } }
        );
        
        if (updatedCount > 0) {
            reply.status(204).send({
                status_code: 204,
                message: 'Expense configuration deleted successfully.',
                trace_id:traceId,
            });
        } else {
            reply.status(404).send({
                status_code: 404,
                message: 'Expense configuration not found.',
                expense_config:[],
                trace_id:traceId,
            });
        }
    } catch (error) {
        reply.status(500).send({
            message: 'An error occurred while deleting expense configuration.',
            trace_id:traceId,
        });
    }
}
