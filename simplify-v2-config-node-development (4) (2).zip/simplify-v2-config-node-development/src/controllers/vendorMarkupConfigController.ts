import { FastifyRequest, FastifyReply } from 'fastify';
import vendorMarkupConfig from '../models/vendorMarkupConfigModel';
import vendorMarkupConfigInterface from '../interfaces/vendorMarkupConfigInterface';
import generateCustomUUID from '../utility/genrateTraceId';
import { baseSearch } from '../utility/baseService';
import { Sequelize } from 'sequelize';

export async function getAllVendorMarkupConfig(request: FastifyRequest, reply: FastifyReply) {
    const searchFields = ['tenant_id', 'is_enabled', 'rate_model', 'sourced_markup', 'program_id'];
    const responseFields = ['id', 'tenant_id', 'program_id', 'is_enabled', 'rate_model', 'sliding_scale', 'hierarchy', 'sourced_markup', 'payrolled_markup'];
    return baseSearch(request, reply, vendorMarkupConfig, searchFields, responseFields)
}

export async function getVendorMarkupConfigById(request: FastifyRequest, reply: FastifyReply) {
    try {
        const { id, program_id } = request.params as { id: string, program_id: string };
        const item = await vendorMarkupConfig.findOne({
            where: {
                id,
                program_id,
                is_deleted: false,
            },
        });
        if (item) {
            reply.status(200).send({
                status_code: 200,
                trace_id: generateCustomUUID(),
                vendor_markup_config: item
            });
        } else {
            reply.status(200).send({
                status_code: 200,
                trace_id: generateCustomUUID(),
                vendor_markup_config: [],
                message: 'vendorMarkupConfig not found.',
            });
        }
    } catch (error) {
        reply.status(500).send({
            status_code: 500,
            trace_id: generateCustomUUID(),
            message: "Internal Server Error",
            error
        });
    }
}

export async function createVendorMarkupConfig(
    request: FastifyRequest<{ Params: { program_id: string } }>,
    reply: FastifyReply
) {
    try {
        const { program_id } = request.params;
        const vendor = request.body as vendorMarkupConfigInterface;

        if (!program_id) {
            return reply.status(400).send({
                status_code: 400,
                trace_id: generateCustomUUID(),
                message: 'Program id is required.',
            });
        }

        const existingVendor = await vendorMarkupConfig.findOne({
            where: {
                id: vendor.id,
                // program_id: program_id
            }
        });

        if (existingVendor) {
            await existingVendor.update({ ...vendor, program_id });
            return reply.status(200).send({
                status_code: 200,
                trace_id: generateCustomUUID(),
                message: 'VendorMarkupConfig updated successfully.',
                vendor: existingVendor
            });
        } else {
            const newVendor = await vendorMarkupConfig.create({ ...vendor, program_id });
            return reply.status(201).send({
                status_code: 201,
                trace_id: generateCustomUUID(),
                message: 'VendorMarkupConfig created successfully.',
                vendor: newVendor
            });
        }
    } catch (error) {
        return reply.status(500).send({
            status_code: 500,
            trace_id: generateCustomUUID(),
            message: "Internal Server Error",
            error: error
        });
    }
}

export async function updateVendorMarkupConfig(request: FastifyRequest, reply: FastifyReply) {
    try {
        const { id, program_id } = request.params as { id: string, program_id: string };
        const data = request.body as vendorMarkupConfigInterface;

        const vendorData = await vendorMarkupConfig.findOne({
            where: { id, program_id, is_deleted: false },
        });

        if (!vendorData) {
            return reply.status(200).send({
                trace_id: generateCustomUUID(),
                message: 'vendorMarkupConfig data not found.',
                vendor_markup_config: [],
            });
        }
        await vendorData.update(data);
        reply.status(201).send({
            status_code: 201,
            message: 'vendorMarkupConfig updated successfully.',
            trace_id: generateCustomUUID(),
        });
    } catch (error) {
        reply.status(500).send({
            message: 'Internal Server Error',
            trace_id: generateCustomUUID(),
        });
    }
}

export async function deleteVendorMarkupConfig(request: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) {
    try {
        const { id, program_id } = request.params as { id: string, program_id: string };
        const vendorData = await vendorMarkupConfig.findOne({
            where: { id, program_id, is_deleted: false },
        });
        if (!vendorData) {
            return reply.status(200).send({ message: 'vendorMarkupConfig data not found.', vendor_markup_config: [] });
        }
        await vendorData.update({ is_enabled: false, is_deleted: true });
        reply.status(204).send({
            status_code: 204,
            trace_id: generateCustomUUID(),
            message: 'vendorMarkupConfig Deleted Successfully.'
        });
    } catch (error) {
        reply.status(500).send({
            status_code: 500,
            trace_id: generateCustomUUID(),
            message: "Internal Server Error",
            error
        });
    }
}

export async function calculateAverageVendorMarkupConfig(request: FastifyRequest, reply: FastifyReply) {
    const trace_id = generateCustomUUID();
    try {
        const { program_id } = request.params as { program_id: string };

        const { program_industry, hierarchy, work_locations, min_rate, max_rate, rate_model } = request.body as {
            min_rate: number;
            max_rate: number;
            program_industry: string;
            hierarchy: string;
            work_locations: string;
            rate_model: string;
        };

        const markupData = await vendorMarkupConfig.findOne({
            where: {
                program_id,
                program_industry,
                hierarchy,
                work_locations,
                is_deleted: false,
            },
            attributes: [
                [Sequelize.fn('MIN', Sequelize.cast(Sequelize.json('markups.sourced_markup'), 'FLOAT')), 'sourced_markup_min'],
                [Sequelize.fn('MAX', Sequelize.cast(Sequelize.json('markups.sourced_markup'), 'FLOAT')), 'sourced_markup_max'],
                [Sequelize.fn('AVG', Sequelize.cast(Sequelize.json('markups.sourced_markup'), 'FLOAT')), 'sourced_markup_avg'],
                [Sequelize.fn('MIN', Sequelize.cast(Sequelize.json('markups.payrolled_markup'), 'FLOAT')), 'payrolled_markup_min'],
                [Sequelize.fn('MAX', Sequelize.cast(Sequelize.json('markups.payrolled_markup'), 'FLOAT')), 'payrolled_markup_max'],
                [Sequelize.fn('AVG', Sequelize.cast(Sequelize.json('markups.payrolled_markup'), 'FLOAT')), 'payrolled_markup_avg'],
            ],
            raw: true,
        });

        if (!markupData) {
            return reply.status(200).send({
                status_code: 200,
                trace_id: generateCustomUUID(),
                markup_aggregate: {},
                message: 'No markups found for vendors.',
            });
        }

        const {
            sourced_markup_min,
            sourced_markup_max,
            sourced_markup_avg,
            payrolled_markup_min,
            payrolled_markup_max,
            payrolled_markup_avg
        } = markupData;

        const avg_markup = (parseFloat(sourced_markup_avg) + parseFloat(payrolled_markup_avg)) / 2;

        const min_markup = Math.min(parseFloat(sourced_markup_min), parseFloat(payrolled_markup_min));
        const max_markup = Math.max(parseFloat(sourced_markup_max), parseFloat(payrolled_markup_max));
        const average_rate = (min_rate + max_rate) / 2;
        let min_bill_rate, max_bill_rate, average_bill_rate;

        if (rate_model === "PAY_RATE") {
            min_bill_rate = min_rate * (1 + min_markup / 100);
            max_bill_rate = max_rate * (1 + max_markup / 100);
            average_bill_rate = average_rate * (1 + avg_markup / 100);
        } else {
            min_bill_rate = min_rate;
            max_bill_rate = max_rate;
            average_bill_rate = average_rate;
        }

        reply.send({
            data: {
                min_bill_rate,
                max_bill_rate,
                average_bill_rate
            },
            trace_id,
        });
    } catch (error) {
        reply.status(500).send({
            message: (error as Error).message,
            trace_id,
        });
    }
}
