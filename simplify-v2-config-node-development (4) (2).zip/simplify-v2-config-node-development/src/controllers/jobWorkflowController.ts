import { FastifyRequest, FastifyReply } from 'fastify';
import JobWorkFlowModel from '../models/jobWorkflowModel';
import generateCustomUUID from '../utility/genrateTraceId';
import { JobWorkFlow, Recipient, Users, Workflow } from '../interfaces/jobWorkflowInterface';
import { sequelize } from '../config/instance';
import { QueryTypes } from 'sequelize';
import FoundationalDataTypes from '../models/foundationalDatatypesModel';
import CustomField from '../models/customFieldsModel';
import RecipientType from '../models/recipientTypesModel';


export const createJobWorkFlow = async (
    request: FastifyRequest<{ Params: { program_id: string } }>,
    reply: FastifyReply
) => {
    const workflow = request.body as JobWorkFlow;
    const traceId = generateCustomUUID();
    const { program_id } = request.params;

    const workflowData = {
        ...workflow,
        program_id,
    };
    try {
        const createdWorkflow = await JobWorkFlowModel.create(workflowData);

        reply.status(201).send({
            status_code: 201,
            trace_id: traceId,
            id: createdWorkflow.id,
            message: 'Workflow created successfully.',
        });
    } catch (error) {
        reply.status(500).send({
            status_code: 500,
            message: 'An error occurred while creating job workflow.',
            trace_id: traceId,
        });
    }
};

export const getAllJobWorkFlow = async (
    request: FastifyRequest<{
        Querystring: { page?: number; limit?: number; workflow_id?: string; method_id?: string; event_id?: string, module: string, job_id: string, module_id?: string },
        Params: { program_id: string }
    }>,
    reply: FastifyReply
) => {
    const traceId = generateCustomUUID();
    const { program_id } = request.params;

    const { page = 1, limit = 10, workflow_id, method_id, event_id, module, job_id, module_id } = request.query;
    const offset = (page - 1) * limit;

    try {
        const whereCondition: any = {
            program_id,
            is_deleted: false,
            ...(workflow_id && { workflow_id }),
            ...(method_id && { method_id }),
            ...(event_id && { event_id }),
            ...(module && { module: module_id }),
            ...(job_id && { job_id }),

        };

        const { rows: workflows, count } = await JobWorkFlowModel.findAndCountAll({
            where: whereCondition,
            limit,
            offset,
        });

        reply.status(200).send({
            status_code: 200,
            trace_id: traceId,
            message: 'Job workflow fetched successfully.',
            total: count,
            page,
            limit,
            job_workflow: workflows,
        });
    } catch (error) {
        reply.status(500).send({
            status_code: 500,
            message: 'Failed to fetch job workflow',
            trace_id: traceId,
            error,
        });
    }
};


export const getJobWorkFlowById = async (
    request: FastifyRequest<{ Params: { program_id: string; id: string } }>,
    reply: FastifyReply
) => {
    const traceId = generateCustomUUID();
    const { program_id, id } = request.params;

    try {
        const workflow = await JobWorkFlowModel.findAll({
            where: {
                id,
                program_id,
                is_deleted: false,
            }
        });

        if (!workflow) {
            return reply.status(400).send({
                status_code: 400,
                trace_id: traceId,
                message: 'Workflow data not found.',
                job_workflow: [],
            });
        }

        reply.status(200).send({
            status_code: 200,
            trace_id: traceId,
            job_workflow: workflow,
        });
    } catch (error) {
        reply.status(500).send({
            status_code: 500,
            message: 'Internal server error.',
            trace_id: traceId,
        });
    }
};

export const updateJobWorkFlow = async (
    request: FastifyRequest<{
        Params: { program_id: string; id: string };
        Body: Partial<JobWorkFlow>;
    }>,
    reply: FastifyReply
) => {
    const traceId = generateCustomUUID();
    const { program_id, id } = request.params;
    const { updateData } = request.body as any;

    try {
        const workflow = await JobWorkFlowModel.findOne({ where: { id, program_id } });

        if (!workflow) {
            return reply.status(200).send({
                status_code: 200,
                message: 'Workflow data not found !',
                trace_id: traceId,
            });
        }

        await workflow.update({ ...updateData, modified_on: new Date() });

        reply.status(200).send({
            status_code: 200,
            message: 'Job workflow updated successfully.',
            trace_id: traceId,
        });
    } catch (error) {
        reply.status(500).send({
            status_code: 500,
            message: 'Failed to update job workflow',
            trace_id: traceId,
        });
    }
};

export async function deleteJobWorkFlow(
    request: FastifyRequest,
    reply: FastifyReply
) {
    const traceId = generateCustomUUID();

    try {
        const { program_id, id } = request.params as { program_id: string, id: string };
        const workflow = await JobWorkFlowModel.findOne({ where: { program_id, id } });

        if (workflow) {
            await JobWorkFlowModel.update({ is_deleted: true, is_enabled: false }, { where: { program_id, id } });

            reply.status(204).send({
                status_code: 204,
                message: 'Job workflow deleted successfully.',
                trace_id: traceId,
            });
        } else {
            reply.status(200).send({
                status_code: 404,
                message: 'Job worklfow not found.',
                trace_id: traceId,
            });
        }
    } catch (error) {
        reply.status(500).send({
            status_code: 500,
            message: 'Failed to delete job workflow',
            trace_id: traceId,
            error,
        });
    }
};

export async function getWorkflowForJob(request: FastifyRequest, reply: FastifyReply) {
    const trace_id = generateCustomUUID();
    const { program_id } = request.params as { program_id: string };

    try {
        const { module_id, event_id, hierarchy_ids, method_id, job_id } = request.query as {
            module_id: string;
            event_id: string;
            method_id: string;
            hierarchy_ids: string;
            job_id: string
        };

        const hierarchyIdsArray = hierarchy_ids.split(',');

        const query = `
            SELECT
                w.id AS workflow_id,
                w.name AS workflow_name,
                w.flow_type AS workflow_type,
                l.id AS level_id,
                l.placement_order AS placement_order,
                r.recipient_type_id,
                r.meta_data,
                r.behaviour
            FROM
                job_workflow w
            INNER JOIN workflow_level l ON l.workflow_id = w.id
            LEFT JOIN workflow_recepient_type r ON r.level_id = l.id
            WHERE
                w.event_id = :event_id
                AND w.module = :module_id
                AND w.program_id = :program_id
                AND w.method_id = :method_id
                AND w.job_id=:job_id
                AND JSON_OVERLAPS(w.hierarchies, JSON_ARRAY(${hierarchyIdsArray.map((id: string) => `"${id}"`).join(',')}))
        `;

        const rows: any[] = await sequelize.query(query, {
            replacements: { module_id, event_id, method_id, program_id, job_id },
            type: QueryTypes.SELECT,
        });

        if (rows.length === 0) {
            return reply.status(200).send({
                statusCode: 200,
                message: 'Workflow data not found',
                workflow: [],
                trace_id,
            });
        }

        const workflow: Workflow = {
            workflow_id: rows[0].workflow_id,
            workflow_name: rows[0].workflow_name,
            workflow_type: rows[0].workflow_type,
            levels: [],
        };

        for (const row of rows) {
            const { level_id, placement_order, recipient_type_id, meta_data, behaviour } = row;

            if (meta_data && Object.keys(meta_data).length > 0) {
                const recipientTypeQuery = `
                    SELECT name
                    FROM recipientType
                    WHERE id = :recipient_type_id
                    LIMIT 1
                `;
                const recipientTypeResult = await sequelize.query(recipientTypeQuery, {
                    type: QueryTypes.SELECT,
                    replacements: { recipient_type_id },
                });

                const recipientType = recipientTypeResult[0] as Recipient;

                let input_value: any;
                const input_values = Object.values(meta_data);

                function getName(input_value: any): string {
                    if ('first_name' in input_value && 'last_name' in input_value) {
                        const firstName = (input_value as { first_name: string; last_name?: string }).first_name;
                        const lastName = (input_value as { first_name: string; last_name?: string }).last_name || '';
                        return `${firstName} ${lastName}`.trim();
                    } else if ('name' in input_value) {
                        return (input_value as { name: string }).name;
                    }
                    return '';
                }

                function getExistingLevel(workflow: Workflow, level_id: string) {
                    return workflow.levels.find(level => level.level_id === level_id);
                }

                if (recipientType?.name === 'Specific User' || recipientType?.name === 'Multiple users') {
                    if (input_values.length > 0) {
                        const userQuery = 
                                `SELECT id, first_name, last_name, avatar, role_id
                                FROM user
                                WHERE id = :user_id
                                LIMIT 1`;
                        const userResult = await sequelize.query<Users>(userQuery, {
                            type: QueryTypes.SELECT,
                            replacements: { user_id: input_values[0] },
                        });

                        input_value = userResult[0] ? {
                            id: userResult[0].id,
                            first_name: userResult[0].first_name,
                            last_name: userResult[0].last_name,
                            avatar: userResult[0].avatar,
                            role_id: userResult[0].role_id,
                        } : undefined;
                    }
                }

                if (["Top of Financial Authority Chain", "Financial Authority Chain", "Managerial Chain", "Manager of"].includes(recipientType?.name)) {
                    const specificRecipientType = await RecipientType.findOne({
                        where: { name: recipientType?.name, program_id }
                    });

                    if (specificRecipientType) {
                        const fieldConfigs = specificRecipientType.parameter_schema?.field_configs || [];
                        fieldConfigs.forEach((config: any) => {
                            const children = config.children || [];
                            const matchingChild = children.find((child: { id: any }) => child.id === input_values);
                            if (matchingChild) {
                                input_value = {
                                    id: matchingChild.id,
                                    name: matchingChild.field?.name || ''
                                } as any;
                            }
                        });
                    }
                }

                if (recipientType?.name === "Custom Field Supplied User") {
                    input_value = await CustomField.findOne({
                        where: { id: input_values },
                        attributes: ["id", "name"]
                    });
                }

                if (recipientType?.name === "Master Data Owner") {
                    input_value = await FoundationalDataTypes.findOne({
                        where: { id: input_values },
                        attributes: ["id", "name"]
                    });
                }

                if (input_value) {
                    const existingLevel = getExistingLevel(workflow, level_id);
                    const recipient = {
                        name: getName(input_value),
                        level_id,
                        user: input_value,
                        recipient_type: recipientType?.name || '',
                        behaviour,
                    };
                    if (existingLevel) {
                        existingLevel.recipients.push(recipient);
                    } else {
                        workflow.levels.push({
                            level_id,
                            placement_order,
                            recipients: [recipient],
                        });
                    }
                }

            }
        }

        return reply.status(200).send({
            statusCode: 200,
            workflow,
            trace_id,
        });
    } catch (error: any) {
        return reply.status(500).send({
            statusCode: 500,
            message: 'An error occurred while fetching workflow data.',
            trace_id,
        });
    }
}

