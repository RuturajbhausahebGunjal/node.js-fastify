import { FastifyRequest, FastifyReply } from 'fastify';
import WorkFlow from '../models/workflowModel';
import { WorkflowData } from '../interfaces/workflowInterface';
import generateCustomUUID from '../utility/genrateTraceId';
import { Op, QueryTypes } from 'sequelize';
import { Module } from '../models/moduleModel';
import EventModel from '../models/eventModel';
import WorkflowMethod from '../models/workflowMethodsModel';
import hierarchies from '../models/hierarchiesModel';
import { logger } from '../utility/loggerService';
import { decodeToken } from '../middlewares/verifyToken';
import RecipientTypeModel from '../models/recipientTypesModel';
import DataSourceModel from '../models/workflowDataSourceModel'
import { sequelize } from '../config/instance';
import {
    countChildWorkflowsQuery,
    getChildWorkflowsQuery,
    getparentWorkflowsQuery
} from '../utility/queries';
import FieldOperatorModel from '../models/field-operator-model'
import FieldConfigModel from '../models/workflowFieldConfigModel'
import FieldModel from '../models/workflowFieldModel'
import WorkflowLevel from '../models/workflowLevelModel';
import WorkflowLevelCondition from '../models/workflowLevelCondition';
import WorkflowRecepientType from '../models/workflowRecipientType';
import User from '../models/userModel';
import FoundationalModel from '../models/foundationalDatatypesModel';
import CustomField from '../models/customFieldsModel';
import FoundationalDataTypes from '../models/foundationalDatatypesModel';
import WorkLocationModel from '../models/workLocationModel';
import IndustriesModel from '../models/industriesModel';
import picklistModel from '../models/picklistModel';
import jobTemplateModel from '../models/job-template.model';
import foundationalData from '../models/foundationalDataModel';


export const createWorkflow = async (request: FastifyRequest, reply: FastifyReply) => {
    const { program_id } = request.params as { program_id: string };
    const { name, workflow_id, levels } = request.body as WorkflowData;
    const trace_id = generateCustomUUID();

    const authHeader = request.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) {
        return reply.status(401).send({ message: 'Unauthorized - Token not found' });
    }

    const token = authHeader.split(' ')[1];
    let user: any = await decodeToken(token);

    if (!user) {
        return reply.status(401).send({ message: 'Unauthorized - Invalid token' });
    }
    try {
        const existingWorkflow = await WorkFlow.findOne({
            where: { name: name, program_id: program_id }
        });

        if (existingWorkflow) {
            logger(
                {
                    trace_id,
                    actor: {
                        user_name: user?.preferred_username,
                        user_id: user?.sub,
                    },
                    data: request.body,
                    eventname: "creating workflow",
                    status: "error",
                    description: `A workflow with the same name already exists for ${program_id}`,
                    level: 'error',
                    action: request.method,
                    url: request.url,
                    entity_id: program_id,
                    is_deleted: false
                },
                WorkFlow
            );

            return reply.status(409).send({
                statusCode: 409,
                message: "A workflow with the same name already exists",
                trace_id,
            });
        }

        const workflowDataPayload = request.body as Omit<WorkflowData, '_id'>;
        let workflowData: any;
        let createdWorkflow: any;
        let grouped = await WorkFlow.findOne({
            where: {
                flow_type: workflowDataPayload.flow_type,
                is_deleted: false,
                program_id,
                event_id: workflowDataPayload.event_id
            }
        });
        if (grouped) {
            createdWorkflow = await WorkFlow.create({
                ...workflowDataPayload,
                program_id,
                workflow_id: grouped.id,
                type: "child"
            });
            await grouped.update({ flow_count: (grouped.flow_count || 0) + 1 });
            await createdWorkflow.update({
                placement_order: grouped.flow_count - 1,
            });
        } else {
            createdWorkflow = await WorkFlow.create({
                ...workflowDataPayload,
                program_id,
                placement_order: 0,
                flow_count: 1,
                type: "parent"
            });
        }
        for (const level of levels) {
            const createdLevel = await WorkflowLevel.create({
                workflow_id: createdWorkflow.id,
                placement_order: level.placement_order,
                program_id: program_id,
            });

            if (Array.isArray(level.conditions)) {
                for (const condition of level.conditions) {
                    await WorkflowLevelCondition.create({
                        program_id: program_id,
                        level_id: createdLevel.id,
                        placement_order: condition.placement_order,
                        indent: condition.indent,
                        operator_id: condition.field_operator_id,
                        field_config_id: condition.field_config,
                        target_field_value: condition.target_field_value,
                    });
                }
            }

            for (const recipient of level.recipient_types || []) {
                await WorkflowRecepientType.create({
                    level_id: createdLevel.id,
                    program_id: program_id,
                    recipient_type_id: recipient.recipient_type_id,
                    meta_data: recipient.meta_data,
                    behaviour: recipient.behaviour,
                });
            }
        }
        logger(
            {
                trace_id,
                actor: {
                    user_name: user?.preferred_username,
                    user_id: user?.sub,
                },
                data: request.body,
                eventname: "creating workflow",
                status: "success",
                description: `Creating workflow for ${program_id} successfully: ${workflowData?.id}`,
                level: 'success',
                action: request.method,
                url: request.url,
                entity_id: program_id,
                is_deleted: false
            },
            WorkFlow
        );

        reply.status(201).send({
            statusCode: 201,
            workflow: {
                id: createdWorkflow?.id,
                name: createdWorkflow?.name,
            },
            trace_id,
        });
    } catch (error: any) {
        logger(
            {
                trace_id,
                actor: {
                    user_name: user?.preferred_username,
                    user_id: user?.sub,
                },
                data: request.body,
                eventname: "creating workflow",
                status: "error",
                description: `Error while creating workflow for ${program_id}`,
                level: 'error',
                action: request.method,
                url: request.url,
                entity_id: program_id,
                is_deleted: false
            },
            WorkFlow
        );
        console.log(error.stack)
        reply.status(500).send({
            statusCode: 500,
            message: 'Error while creating workflow',
            trace_id
        });
    }
};

export const updateWorkflow = async (request: FastifyRequest, reply: FastifyReply) => {
    const { id, program_id } = request.params as { id: string, program_id: string };
    const workflowData = request.body as WorkflowData;
    const { name } = request.body as WorkflowData;
    const trace_id = generateCustomUUID();
    try {
        const existingWorkFlowWithSameName = await WorkFlow.findOne({
            where: {
                name,
                program_id,
                id: { [Op.ne]: id },
            },
        });

        if (existingWorkFlowWithSameName) {
            return reply.status(400).send({
                statusCode: 400,
                message: "A workflow with the same name already exists",
                trace_id
            });
        }

        const data = await WorkFlow.findOne({
            where: { id, is_deleted: false, program_id }
        });
        if (data) {
            await data.update(workflowData);
            reply.status(201).send({
                statusCode: 201,
                workflow_id: id,
                message: 'Workflow updated successfully.',
                trace_id
            });
        } else {
            reply.status(200).send({ message: 'Workflow data not found.' });
        }
    } catch (error) {
        reply.status(500).send({
            statusCode: 500,
            message: ' An error occurred while updating the workflow',
            trace_id
        });
    }
}

export const updateReorder = async (
    request: FastifyRequest<{
        Params: { program_id: string; module: string; event_id: string, flow_type: string };
        Body: { flow_order: string[] }
    }>,
    reply: FastifyReply
) => {
    const { program_id, module, event_id, flow_type } = request.params;
    const { flow_order } = request.body;
    const trace_id = generateCustomUUID();

    try {
        const workflows = await WorkFlow.findAll({
            where: {
                id: flow_order,
                program_id,
                module,
                event_id,
                flow_type,
                is_deleted: false
            }
        });

        const existingIds = workflows.map(workflow => workflow.id);
        const missingIds = flow_order.filter(id => !existingIds.includes(id));

        if (missingIds.length > 0) {
            return reply.status(404).send({
                statusCode: 404,
                message: `Some workflows not found: ${missingIds.join(', ')}`,
                trace_id
            });
        }

        for (let index = 0; index < flow_order.length; index++) {
            const workflowId = flow_order[index];
            await WorkFlow.update(
                { placement_order: index + 1 },
                {
                    where: {
                        id: workflowId,
                        program_id,
                        module,
                        event_id,
                        flow_type,
                        is_deleted: false
                    }
                }
            );
        }

        reply.status(200).send({
            statusCode: 200,
            message: 'Workflow placement order updated successfully.',
            trace_id
        });

    } catch (error) {
        console.log(error);
        reply.status(500).send({
            statusCode: 500,
            message: 'An error occurred while updating the workflow placement order.',
            trace_id
        });
    }
};

export async function deleteWorkflow(
    request: FastifyRequest<{ Params: { program_id: string, id: string } }>,
    reply: FastifyReply
) {
    const traceId = generateCustomUUID()
    try {
        const { program_id, id } = request.params;
        const workFlowData = await WorkFlow.findOne({ where: { program_id, id } });
        if (workFlowData) {
            await WorkFlow.update({ is_deleted: true, is_enabled: false }, { where: { program_id, id } });
            reply.status(204).send({
                status_code: 204,
                message: 'Workflow deleted successfully.',
                trace_id: traceId,
            });
        } else {
            reply.status(404).send({
                status_code: 404,
                message: 'Workflow not found.'
            });
        }
    } catch (error) {
        reply.status(500).send({
            message: 'An error occurred while deleting workflow.',
            trace_id: traceId,
            error: error,
        });
    }
}

export async function getAllWorkflows(
    request: FastifyRequest<{ Params: WorkflowData, Querystring: WorkflowData }>,
    reply: FastifyReply
) {
    const trace_id = generateCustomUUID();
    try {
        const params = request.params;
        const query = request.query as WorkflowData | any;
        const page = parseInt(query.page ?? "1");
        const limit = parseInt(query.limit ?? "10");
        const offset = (page - 1) * limit;
        query.page && delete query.page;
        query.limit && delete query.limit;

        const searchConditions: any = { is_deleted: false, program_id: params.program_id };

        if (query.name) {
            searchConditions.name = { [Op.like]: `%${query.name}%` };
        }
        if (query.is_enabled !== undefined) {
            searchConditions.is_enabled = query.is_enabled === "false" ? false : true;
        }
        if (query.module) {
            searchConditions.module = query.module;
        }
        if (query.event_id) {
            searchConditions.event_id = query.event_id;
        }
        if (query.method_id) {
            searchConditions.method_id = query.method_id;
        }
        if (query.type) {
            searchConditions.type = query.type;
        }

        const { rows: workflows, count } = await WorkFlow.findAndCountAll({
            where: searchConditions,
            attributes: { exclude: ["program_id"] },
            limit: limit,
            offset: offset,
            order: [["created_on", "DESC"]],
        });

        if (workflows.length === 0) {
            return reply.status(200).send({
                message: "Workflow not found",
                workflow: [],
                trace_id
            });
        }

        const populatedWorkflow = await Promise.all(workflows.map(async (workflow) => {
            const module_id = workflow.module;
            const event_id = workflow.event_id;
            const method_id = workflow.method_id;

            const moduleData = module_id ? await Module.findByPk(module_id, { attributes: ["id", "name"] }) : null;
            const eventData = event_id ? await EventModel.findByPk(event_id, { attributes: ["id", "name"] }) : null;
            const methodData = method_id ? await WorkflowMethod.findByPk(method_id, { attributes: ["id", "name"] }) : null;

            const hierarchyIds = workflow.hierarchies || [];
            const hierarchiesData = hierarchyIds.length ? await hierarchies.findAll({
                where: { id: { [Op.in]: hierarchyIds } },
                attributes: ['id', 'name']
            }) : [];

            return {
                ...workflow.toJSON(),
                Module: moduleData ? moduleData.toJSON() : null,
                Event: eventData ? eventData.toJSON() : null,
                Method: methodData ? methodData.toJSON() : null,
                hierarchies: hierarchiesData.map(hierarchy => ({
                    id: hierarchy.get('id'),
                    name: hierarchy.get('name')
                })),
            };
        }));
        reply.status(200).send({
            statusCode: 200,
            total_records: count,
            workflow: populatedWorkflow,
            trace_id
        });
    } catch (error) {
        reply.status(500).send({
            statusCode: 500,
            message: "Internal server error",
            trace_id
        });
    }
}

export async function getWorkflowById(request: FastifyRequest, reply: FastifyReply) {
    const trace_id = generateCustomUUID();
    try {
        const { id, program_id } = request.params as { id: string; program_id: string };
        const item = await WorkFlow.findOne({
            where: { id, program_id }
        });

        if (!item) {
            return reply.status(200).send({
                statusCode: 200,
                message: 'Workflow data not found',
                workflow: [],
                trace_id
            });
        }

        const [moduleData, eventData, methodData, hierarchiesData] = await Promise.all([
            item.module ? Module.findByPk(item.module, { attributes: ["id", "name"] }) : null,
            item.event_id ? EventModel.findByPk(item.event_id, { attributes: ["id", "name"] }) : null,
            item.method_id ? WorkflowMethod.findByPk(item.method_id, { attributes: ["id", "name"] }) : null,
            item.hierarchies?.length ? hierarchies.findAll({
                where: { id: { [Op.in]: item.hierarchies } },
                attributes: ['id', 'name']
            }) : []
        ]);

        const fieldOperatorIds = new Set<string>();
        const metaFieldConfigIds = new Set<string>();
        const selectedItems = new Set<string>();
        const targetValues = new Set<string>();

        item.levels.forEach((level: any) => {
            level.recipient_types?.forEach((recipientType: any) => {
                const metaData = recipientType.meta_data || {};
                Object.keys(metaData).forEach(fieldConfigId => metaFieldConfigIds.add(fieldConfigId));
            });

            level.conditions?.forEach((condition: any) => {
                if (condition.field_operator_id) {
                    fieldOperatorIds.add(condition.field_operator_id);
                }
                if (condition.field_config) {
                    metaFieldConfigIds.add(condition.field_config);
                }
                if (condition.source_field_meta?.selected_item) {
                    selectedItems.add(condition.source_field_meta.selected_item);
                }

                if (condition.target_field_value?.values) {
                    if (Array.isArray(condition.target_field_value.values)) {
                        condition.target_field_value.values.forEach((value: any) => {
                            targetValues.add(value);
                        });
                    } else {
                        targetValues.add(condition.target_field_value.values);
                    }
                }
            });
        });

        const [fieldConfigs, fieldOperators, selectedItemDetails, foundationalDetails, workLocationDetails, labourCategoryDetails, createOrgDetail, masterDataDetails, jobTemplateDetails] = await Promise.all([
            FieldConfigModel.findAll({
                where: { id: { [Op.in]: Array.from(metaFieldConfigIds) } },
                attributes: ['id', 'config', 'field_id', 'placement_order'],
                include: [
                    {
                        model: FieldModel,
                        as: 'field',
                        include: [
                            {
                                model: DataSourceModel,
                                as: 'data_source',
                                attributes: ['id', 'name', 'slug', 'api_url']
                            }
                        ]
                    }
                ]
            }),
            FieldOperatorModel.findAll({
                where: { id: { [Op.in]: Array.from(fieldOperatorIds) } },
                attributes: ['id', 'sign', 'eval_text', 'is_separator']
            }),
            CustomField.findAll({
                where: { id: { [Op.in]: Array.from(selectedItems) } },
                attributes: ['id', 'name', 'slug']
            }),
            FoundationalModel.findAll({
                where: { id: { [Op.in]: Array.from(selectedItems) } },
                attributes: ['id', 'name',]
            }),
            WorkLocationModel.findAll({
                where: { id: { [Op.in]: Array.from(targetValues) } },
                attributes: ['id', 'name']
            }),

            IndustriesModel.findAll({
                where: { id: { [Op.in]: Array.from(targetValues) } },
                attributes: ['id', 'name']
            }),
            picklistModel.findAll({
                where: { id: { [Op.in]: Array.from(targetValues) } },
                attributes: ['id', 'name']
            }),
            foundationalData.findAll({
                where: { id: { [Op.in]: Array.from(targetValues) } },
                attributes: ['id', 'name']
            }),
            jobTemplateModel.findAll({
                where: { id: { [Op.in]: Array.from(targetValues) } },
                attributes: ['id', 'template_name']
            }),
        ]);

        const fieldConfigMap = fieldConfigs.reduce((acc: any, config: any) => {
            acc[config.id] = {
                id: config.id,
                placement_order: config.placement_order,
                config: config.config,
                field: config.field
            };
            return acc;
        }, {});

        const fieldOperatorMap = fieldOperators.reduce((acc: any, operator: any) => {
            acc[operator.id] = operator;
            return acc;
        }, {});

        const selectedItemMap = selectedItemDetails.reduce((acc: any, item: any) => {
            acc[item.id] = item;
            return acc;
        }, {});
        const masterItemMap = foundationalDetails.reduce((acc: any, item: any) => {
            acc[item.id] = item;
            return acc;
        }, {});

        const targetItemMap = workLocationDetails.reduce((acc: any, item: any) => {
            acc[item.id] = item;
            return acc;
        }, {});
        const labourCategoryItemMap = labourCategoryDetails.reduce((acc: any, item: any) => {
            acc[item.id] = item;
            return acc;
        }, {});
        const createOrgItemMap = createOrgDetail.reduce((acc: any, item: any) => {
            acc[item.id] = item;
            return acc;
        }, {});
        const masterDataMap = masterDataDetails.reduce((acc: any, item: any) => {
            acc[item.id] = item;
            return acc;
        }, {});
        const jobTemplateMap = jobTemplateDetails.reduce((acc: any, item: any) => {
            acc[item.id] = item;
            return acc;
        }, {});
        const levelsWithDetails = await Promise.all(
            item.levels.map(async (level: { recipient_types: any[], conditions: any[] }) => {
                if (Array.isArray(level.recipient_types)) {
                    const recipientTypeIds = level.recipient_types.map(rt => rt.recipient_type_id);
                    const recipientTypes = await RecipientTypeModel.findAll({
                        where: { id: { [Op.in]: recipientTypeIds } },
                        attributes: ['id', 'name', 'meta_data', 'slug']
                    });

                    level.recipient_types = await Promise.all(level.recipient_types.map(async rt => {
                        const recipientType = recipientTypes.find(r => r.id === rt.recipient_type_id);
                        const meta_data = rt.meta_data || {};
                        const populatedMetaData = Object.keys(meta_data).reduce((acc: any, fieldConfigId: string) => {
                            const fieldConfig = fieldConfigMap[fieldConfigId];
                            if (fieldConfig) {
                                acc[fieldConfigId] = {
                                    id: fieldConfig.id,
                                    name: fieldConfig.name,
                                    slug: fieldConfig.slug,
                                    config: fieldConfig.config,
                                    field: fieldConfig.field_id
                                };
                            }
                            return acc;
                        }, {});

                        const input_values = Object.values(meta_data)[0];
                        const input_val = Object.values(meta_data)[1];
                        let input_value: CustomField | User | FoundationalDataTypes | null = null;

                        let behaviour = rt.behaviour;
                        if (behaviour == undefined || behaviour == null) {
                            if (["Top of Financial Authority Chain", "Financial Authority Chain", "Managerial Chain"].includes(recipientType?.name)) {
                                behaviour = "CHAIN";
                            } else if (["Manager of", "Master Data Owner", "Specific User", "Multiple users", "Vendor Users", "Users in Program Role", "Custom Field Supplied User"].includes(recipientType?.name)) {
                                behaviour = "ANY";
                            }
                        }

                        if (["Top of Financial Authority Chain", "Financial Authority Chain", "Managerial Chain", "Manager of"].includes(recipientType?.name)) {
                            const specificRecipientType = await RecipientTypeModel.findOne({
                                where: { name: recipientType?.name, program_id }
                            });

                            if (specificRecipientType) {
                                const fieldConfigs = specificRecipientType.parameter_schema?.field_configs || [];
                                fieldConfigs.forEach((config: any) => {
                                    const children = config.children || [];
                                    const matchingChild = children.find((child: { id: any }) => child.id === input_values);
                                    if (matchingChild) {
                                        input_value = {
                                            id: matchingChild.id,
                                            name: matchingChild.field?.name || ''
                                        } as any;
                                    }
                                });
                            }
                        } else if (recipientType?.name === "Specific User" || recipientType?.name === "Multiple users") {
                            input_value = await User.findOne({
                                where: { id: input_values },
                                attributes: ["id", "first_name", "last_name"]
                            });
                        } else if (recipientType?.name === "Custom Field Supplied User") {
                            input_value = await CustomField.findOne({
                                where: { id: input_values },
                                attributes: ["id", "name"]
                            });
                        } else if (recipientType?.name === "Master Data Owner") {
                            input_value = await FoundationalDataTypes.findOne({
                                where: { id: input_values },
                                attributes: ["id", "name"]
                            });
                        }

                        function getName(input_value: any): string {
                            if ('first_name' in input_value && 'last_name' in input_value) {
                                const firstName = (input_value as { first_name: string; last_name?: string }).first_name;
                                const lastName = (input_value as { first_name: string; last_name?: string }).last_name || '';
                                return `${firstName} ${lastName}`.trim();
                            } else if ('name' in input_value) {
                                return (input_value as { name: string }).name;
                            }
                            return '';
                        }

                        Object.keys(meta_data).forEach((fieldConfigId, index) => {
                            if (!populatedMetaData[fieldConfigId]) {
                                populatedMetaData[fieldConfigId] = {};
                            }

                            if (index === 0) {
                                if (Array.isArray(input_value)) {
                                    populatedMetaData[fieldConfigId].input_value = input_value.map((value: any) => ({
                                        id: value.id,
                                        name: getName(value)
                                    }));
                                } else {
                                    populatedMetaData[fieldConfigId].input_value = input_value
                                        ? input_value.id ? [{
                                            id: input_value.id,
                                            name: getName(input_value)
                                        }] : input_value
                                        : [];
                                }
                            } else if (index === 1) {
                                populatedMetaData[fieldConfigId].input_value = input_val;
                            }
                        });

                        return {
                            id: rt.id,
                            behaviour: behaviour,
                            recipient_type: recipientType || null,
                            metadata: populatedMetaData
                        };
                    }));
                }


                if (Array.isArray(level.conditions)) {
                    level.conditions = level.conditions.map(condition => {
                        if (condition.field_operator_id) {
                            condition.field_operator = fieldOperatorMap[condition.field_operator_id];
                        }
                        if (condition.field_config) {
                            const fieldConfig = fieldConfigMap[condition.field_config];
                            condition.field_config = fieldConfig;
                            condition.field = fieldConfig ? {
                                id: fieldConfig.id,
                                name: fieldConfig.name,
                                slug: fieldConfig.slug
                            } : null;
                        }
                        if (condition.source_field_meta?.selected_item) {
                            const selectedItem = selectedItemMap[condition.source_field_meta.selected_item];
                            if (selectedItem) {
                                condition.source_field_meta = {
                                    id: selectedItem.id,
                                    name: selectedItem.name,
                                    slug: selectedItem.slug
                                };
                            }
                            const masterDataItem = masterItemMap[condition.source_field_meta.selected_item];
                            if (masterDataItem) {
                                condition.source_field_meta = {
                                    id: masterDataItem.id,
                                    name: masterDataItem.name

                                };
                            } delete condition.source_field_meta.selected_item;

                        }

                        const targetMaps = [
                            { map: targetItemMap, key: 'targetItem' },
                            { map: labourCategoryItemMap, key: 'labourCategoryItem' },
                            { map: masterDataMap, key: 'masterDataItem' },
                            { map: createOrgItemMap, key: 'createOrgItem' },
                            { map: jobTemplateMap, key: 'jobTemplateItem', nameField: 'template_name' },
                        ];

                        if (condition.target_field_value?.values) {
                            const values = Array.isArray(condition.target_field_value.values)
                                ? condition.target_field_value.values
                                : [condition.target_field_value.values];

                            condition.target_field_obj = values.flatMap((value: string | number) => {
                                for (const { map, nameField } of targetMaps) {
                                    const item = map[value];
                                    if (item) {
                                        return {
                                            id: item.id || item[nameField || 'name'],
                                            name: item[nameField || 'name']
                                        };
                                    }
                                }
                                return {
                                    id: `${value}`,
                                    name: `${value}`
                                };
                            }).filter(Boolean);
                        } else {
                            condition.target_field_obj = null;
                        }



                        return condition;
                    })
                }
                return level;
            })
        );

        const workflow = {
            ...item.toJSON(),
            Module: moduleData ? moduleData.toJSON() : null,
            Event: eventData ? eventData.toJSON() : null,
            Method: methodData ? methodData.toJSON() : null,
            hierarchies: hierarchiesData.map(hierarchy => ({
                id: hierarchy.get('id'),
                name: hierarchy.get('name')
            })),
            levels: levelsWithDetails
        };

        reply.status(200).send({
            statusCode: 200,
            workflow,
            trace_id
        });
    } catch (error: any) {
        console.log(error);
        reply.status(500).send({
            statusCode: 500,
            error: error.message,
            message: 'An error occurred while fetching workflow data.',
            trace_id
        });
    }
}

export async function getChildWorkflows(request: FastifyRequest, reply: FastifyReply) {
    const trace_id = generateCustomUUID();
    try {
        const params = request.params as {
            workflow_id: string;
            program_id: string;
            flow_type: string;
        };
        const query = request.query as any;

        const filters: any = {
            workflow_id: params.workflow_id,
            program_id: params.program_id,
            flow_type: params.flow_type,
            is_enabled: query.is_enabled !== undefined ? (query.is_enabled === 'true' ? 1 : 0) : null,
            name: query.name ? `%${query.name}%` : null,
        };

        const hierarchyIds = query.hierarchy_id ? query.hierarchy_id.split(',') : [];
        hierarchyIds.forEach((id: any, index: number) => {
            filters[`hierarchy_id_${index + 1}`] = id;
        });

        const parentWorkflow = await sequelize.query(getparentWorkflowsQuery(hierarchyIds.length), {
            replacements: filters,
            type: QueryTypes.SELECT
        });

        const childWorkflows = await sequelize.query(getChildWorkflowsQuery(hierarchyIds.length), {
            replacements: filters,
            type: QueryTypes.SELECT
        });

        if ((!parentWorkflow || parentWorkflow.length === 0) && (!childWorkflows || childWorkflows.length === 0)) {
            return reply.status(200).send({
                statusCode: 200,
                message: "Workflow not found",
                workflows: [],
                trace_id
            });
        }

        let totalRecords = 0;
        if (childWorkflows && childWorkflows.length > 0) {
            const totalCountResult = await sequelize.query(countChildWorkflowsQuery(hierarchyIds.length), {
                replacements: filters,
                type: QueryTypes.SELECT
            }) as [{ total_workflows: number }];

            const totalChild = totalCountResult[0]?.total_workflows || 0;
            totalRecords = totalChild + (parentWorkflow && parentWorkflow.length > 0 ? 1 : 0);
        } else {
            totalRecords = parentWorkflow.length > 0 ? 1 : 0;
        }

        const workflows = parentWorkflow && parentWorkflow.length > 0
            ? [...parentWorkflow, ...childWorkflows]
            : [...childWorkflows];
        workflows.sort((a: any, b: any) => a.placement_order - b.placement_order);
        reply.status(200).send({
            statusCode: 200,
            total_records: totalRecords,
            message: "Workflows fetched successfully.",
            workflows,
            trace_id,
        });
    } catch (error: any) {
        reply.status(500).send({
            statusCode: 500,
            message: "An error occurred while fetching workflow data.",
            trace_id
        });
    }
}
