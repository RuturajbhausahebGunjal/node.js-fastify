import { FastifyRequest, FastifyReply } from 'fastify';
import { RateCardModel } from '../models/rateCardConfigurationModel';
import { MinMaxRateResult, RateCardInterface } from '../interfaces/rateCardConfigurationInterface';
import generateCustomUUID from '../utility/genrateTraceId';
import RateCardMapping from '../models/RateCardMappingModel';
import { sequelize } from '../config/instance';
import { Op, QueryTypes } from 'sequelize';
import {
    rateCardQuery,
    getCountQuery,
    getAllRateCardQuery,
    validateRateConfiguration, minMaxRateQuery, rateModelQuery,
    shiftTypeConfigQuery,
    rateTypeConfigQuery,
    existingPairQuery
} from '../utility/queries';
import hierarchies from '../models/hierarchiesModel';

export async function getAllRateCard(
    request: FastifyRequest<{ Params: RateCardInterface, Querystring: RateCardInterface }>,
    reply: FastifyReply
) {
    const trace_id = generateCustomUUID();
    try {
        const params = request.params as Partial<RateCardInterface>;
        const query = request.query as any;

        const page = parseInt(query.page ?? '1');
        const limit = parseInt(query.limit ?? '10');
        const offset = (page - 1) * limit;

        const filters: any = {
            program_id: params.program_id,
            limit,
            offset,
            is_enabled: query.is_enabled !== undefined ? query.is_enabled === 'true' : null,
            is_shift_rate: query.is_shift_rate === "true" ? true : (query.is_shift_rate === "false" ? false : null),
            name: query.name ? `%${query.name}%` : null,
        };

        const hierarchyIds = query.hierarchy_id ? query.hierarchy_id.split(',') : [];
        hierarchyIds.forEach((id: any, index: number) => {
            filters[`hierarchy_id_${index + 1}`] = id;
        });

        const jobTemplateIds = query.job_template_id ? query.job_template_id.split(',') : [];
        jobTemplateIds.forEach((id: any, index: number) => {
            filters[`job_template_id_${index + 1}`] = id;
        });

        const rateCardQuery = getAllRateCardQuery(hierarchyIds.length, jobTemplateIds.length);
        const countQuery = getCountQuery(hierarchyIds.length, jobTemplateIds.length);

        const [rateCardResult, countResult] = await Promise.all([
            sequelize.query(rateCardQuery, {
                replacements: filters,
                type: QueryTypes.SELECT,
            }),
            sequelize.query(countQuery, {
                replacements: filters,
                type: QueryTypes.SELECT,
            })
        ]);

        const totalRecords = (countResult[0] as any).total;

        if (rateCardResult.length === 0) {
            return reply.status(200).send({
                statusCode: 200,
                message: "Rate card not found",
                rate_card: [],
                trace_id
            });
        }

        const rateCardArray = rateCardResult.map((row: any) => ({
            ...row,
            hierarchies: row.hierarchies ? JSON.parse(`[${row.hierarchies}]`) : [],
            job_templates: row.job_templates ? JSON.parse(`[${row.job_templates}]`) : []
        }));

        reply.status(200).send({
            statusCode: 200,
            total_records: totalRecords,
            rate_card: rateCardArray,
            trace_id,
        });
    } catch (error) {
        reply.status(500).send({
            statusCode: 500,
            message: 'Internal server error',
            trace_id
        });
    }
}

export const saveRateCard = async (request: FastifyRequest, reply: FastifyReply) => {
    const trace_id = generateCustomUUID();
    const transaction = await sequelize.transaction();
    try {
        const { program_id } = request.params as { program_id: string };
        const RateCardConfigurationPayload = request.body as Omit<RateCardInterface, '_id'>;

        if (!Array.isArray(RateCardConfigurationPayload.hierarchies) || RateCardConfigurationPayload.hierarchies.length === 0 ||
            !Array.isArray(RateCardConfigurationPayload.job_templates) || RateCardConfigurationPayload.job_templates.length === 0) {
            return reply.status(400).send({
                status_code: 400,
                message: "Hierarchies and Job templates are required.",
                trace_id,
            });
        }

        const existingConfig = await RateCardModel.findOne({
            where: {
                program_id,
                is_deleted:false,
                name: RateCardConfigurationPayload.name,
            },
            transaction,
        });

        if (existingConfig) {
            return reply.status(409).send({
                status_code: 409,
                message: "A rate configuration with this name already exists.",
                trace_id,
            });
        }

        const fieldToCheck = RateCardConfigurationPayload.is_shift_rate ? 'shift_type' : 'rate_type_name';
        const rateTypeCondition = validateRateConfiguration(fieldToCheck, RateCardConfigurationPayload, program_id);
        const [matches] = await sequelize.query(rateTypeCondition, { transaction });

        if (matches.length > 0) {
            return reply.status(400).send({
                status_code: 400,
                message: "This rate configuration already exists!",
                trace_id,
            });
        }

        const [existingPairs] = await sequelize.query(existingPairQuery, {
            replacements: { program_id, hierarchies: RateCardConfigurationPayload.hierarchies, jobTemplates: RateCardConfigurationPayload.job_templates },
            transaction,
        });

        if (existingPairs.length > 0) {
            return reply.status(400).send({
                status_code: 400,
                message: "A rate configuration with the same hierarchies and job templates already exists.",
                trace_id,
            });
        }

        const RateCardConfigurationData = await RateCardModel.create(
            { ...RateCardConfigurationPayload, program_id },
            { transaction }
        );

        if (Array.isArray(RateCardConfigurationPayload.hierarchies)) {
            await Promise.all(
                RateCardConfigurationPayload.hierarchies.map(hierarchy_id =>
                    RateCardMapping.create({
                        program_id,
                        rate_card_config_id: RateCardConfigurationData.id,
                        hierarchy_id,
                    }, { transaction })
                )
            );
        }

        await transaction.commit();
        reply.status(201).send({
            status_code: 201,
            rate_card_config_id: RateCardConfigurationData.id,
            trace_id,
        });
    } catch (error: any) {
        await transaction.rollback();
        if (error.name === "SequelizeUniqueConstraintError") {
            const field = error.errors[0].path;
            return reply.status(409).send({ error: `${field} already in use.` });
        }
        reply.status(500).send({
            error: error.message || 'Error while creating rate card config.',
            trace_id,
        });
    }
};

export const updateRateCardById = async (request: FastifyRequest, reply: FastifyReply) => {
    const trace_id = generateCustomUUID();
    const { id, program_id } = request.params as { id: string, program_id: string };
    const RateCardConfigurationData = request.body as RateCardInterface;
    const transaction = await sequelize.transaction();
    try {
        const data = await RateCardModel.findOne({
            where: { id, program_id, is_deleted: false },
            transaction
        });
        if (!data) {
            return reply.status(200).send(
                {
                    message: 'Rate card config not found.',
                    trace_id
                }
            );
        }
        const UpdatedRateCardConfiguration = await data.update(RateCardConfigurationData);
        const { hierarchies } = UpdatedRateCardConfiguration as any;
        if (hierarchies) {
            const existingMappings = await RateCardMapping.findAll({
                where: { program_id },
                attributes: ['hierarchy_id'],
                transaction
            });

            const existingMappingIds = existingMappings.map(mapping => mapping.hierarchy_id);
            const mappingsToAdd = hierarchies.filter((id: any) => !existingMappingIds.includes(id));
            const mappingsToRemove = existingMappingIds.filter(id => !hierarchies.includes(id));

            if (mappingsToRemove.length > 0) {
                await RateCardMapping.destroy(
                    {
                        where: {
                            rate_card_config_id: id,
                            program_id,
                            hierarchy_id: { [Op.in]: mappingsToRemove }
                        },
                        transaction
                    }
                );
            }

            if (mappingsToAdd.length > 0) {
                const newMappings = mappingsToAdd.map((id: any) => ({
                    program_id,
                    rate_card_config_id: id,
                    hierarchy_id: id,
                }));
                await RateCardMapping.bulkCreate(newMappings, { transaction });
            }
            await transaction.commit();
        }
        reply.send({
            success: true,
            message: 'Rate card config and mappings updated successfully.',
            trace_id
        });
    } catch (error) {
        await transaction.rollback();
        reply.status(500).send({ message: 'An error occurred while updating the rate card config', trace_id });
    }
}

export const getRateCardById = async (
    request: FastifyRequest<{ Params: { id: string } }>,
    reply: FastifyReply
) => {
    const trace_id = generateCustomUUID();
    const { id } = request.params as { id: string };
    try {
        const rateCardResult = await sequelize.query(rateCardQuery, {
            replacements: {
                id,
            },
            type: QueryTypes.SELECT,
        });
        if (rateCardResult.length === 0) {
            return reply.status(200).send({
                status_code: 200,
                message: 'Rate card not found',
                rate_card: [],
                trace_id
            });
        }

        const rateCardArray = rateCardResult.map((row: any) => ({
            ...row,
            is_shift_rate: !!row.is_shift_rate,
            hierarchies: row.hierarchies ? JSON.parse(`[${row.hierarchies}]`) : [],
            job_templates: row.job_templates ? JSON.parse(`[${row.job_templates}]`) : []
        }));

        reply.status(200).send({
            status_code: 200,
            rate_card: rateCardArray,
            trace_id,
        });
    } catch (error) {
        reply.status(500).send({
            status_code: 500,
            message: 'Internal server error',
            trace_id
        });
    }
};

export async function deleteRateCardById(
    request: FastifyRequest<{ Params: { id: string } }>,
    reply: FastifyReply
) {
    const trace_id = generateCustomUUID();
    try {
        const { id } = request.params;
        const rateCard = await RateCardModel.findByPk(id);
        if (rateCard) {
            await rateCard.update({
                is_enabled: false,
                is_deleted: true,
            })
            reply.status(200).send({
                status_code: 200,
                message: 'Rate card deleted successfully',
                trace_id,
            });
        } else {
            reply.status(200).send({
                status_code: 200,
                message: 'Rate card not found',
                trace_id
            });
        }
    } catch (error) {
        reply.status(500).send({
            status_code: 500,
            message: 'Internal server error',
            trace_id
        });
    }
}

export async function getRateType(
    request: FastifyRequest<{ Params: RateCardInterface, Querystring: RateCardInterface }>,
    reply: FastifyReply
) {
    const trace_id = generateCustomUUID();
    try {
        const params = request.params as Partial<RateCardInterface>;
        const query = request.query as any;

        const page = parseInt(query.page ?? '1');
        const limit = parseInt(query.limit ?? '10');
        const offset = (page - 1) * limit;

        const filters: any = {
            program_id: params.program_id,
            limit,
            offset,
            is_enabled: query.is_enabled !== undefined ? query.is_enabled === 'true' : null,
            is_shift_rate: query.is_shift_rate !== undefined ? query.is_shift_rate : null,
        };

        const hierarchyIds = query.hierarchy_id ? query.hierarchy_id.split(',') : [];
        hierarchyIds.forEach((id: any, index: number) => {
            filters[`hierarchy_id_${index + 1}`] = id;
        });

        const jobTemplateIds = query.job_template_id ? query.job_template_id.split(',') : [];
        jobTemplateIds.forEach((id: any, index: number) => {
            filters[`job_template_id_${index + 1}`] = id;
        });

        const rateTypeQuery = rateTypeConfigQuery(hierarchyIds.length, jobTemplateIds.length);

        const [rateTypeResult] = await Promise.all([
            sequelize.query(rateTypeQuery, {
                replacements: filters,
                type: QueryTypes.SELECT,
            })
        ]);

        if (rateTypeResult.length === 0) {
            return reply.status(200).send({
                message: "Rate type not found",
                rate_types: [],
                trace_id
            });
        }
        reply.status(200).send({
            statusCode: 200,
            rate_types: rateTypeResult,
            trace_id,
        });
    } catch (error) {
        reply.status(500).send({
            statusCode: 500,
            message: 'Internal server error',
            trace_id
        });
    }
}

export async function getShiftTypes(
    request: FastifyRequest<{ Params: { program_id: string }, Querystring: { hierarchy_ids?: string, job_template_ids?: string } }>, 
    reply: FastifyReply
) {
    const trace_id = generateCustomUUID(); 
    const program_id = request.params.program_id;
    const { job_template_ids, hierarchy_ids } = request.query;

    if (!job_template_ids || !hierarchy_ids) {
        return reply.status(400).send({
            status_code: 400,
            message: 'Missing required query parameters: job_template_ids and hierarchy_ids are both required.'
        });
    }

    try {
        const filters: any = {
            is_deleted: 0,  
            is_enabled: 1,
            is_shift_rate: 1,
            program_id: program_id
        };

        const hierarchyIdsArray = hierarchy_ids.split(',');
        const jobTemplateIdsArray = job_template_ids.split(',');

        const shiftTypesQuery = `
            SELECT rate_configuration
            FROM rate_card_configuration
            WHERE is_deleted = :is_deleted
              AND is_enabled = :is_enabled
              AND is_shift_rate = :is_shift_rate
              AND program_id = :program_id
              AND JSON_CONTAINS(hierarchies, JSON_ARRAY(${hierarchyIdsArray.map(id => `"${id}"`).join(',')}))
              AND JSON_CONTAINS(job_templates, JSON_ARRAY(${jobTemplateIdsArray.map(id => `"${id}"`).join(',')}))
        `;

        const shiftTypeResult = await sequelize.query(shiftTypesQuery, {
            replacements: filters,
            type: QueryTypes.SELECT,
        });
        if (shiftTypeResult.length === 0) {
            return reply.status(200).send({
                message: "Shift types not found",
                shift_types: [],
                trace_id
            });
        }

        const shiftTypes = Array.from(new Set(
            shiftTypeResult.flatMap((row: any) => 
                row.rate_configuration?.map((config: any) => config.shift_type)
            ).filter((shiftType: any) => shiftType !== null)
        ));

        reply.status(200).send({
            statusCode: 200,
            shift_types: shiftTypes,
            trace_id,
        });

    } catch (error) {
        console.error('Error fetching shift types:', error);
        reply.status(500).send({
            statusCode: 500,
            message: 'Internal server error',
            trace_id
        });
    }
}



const getHierarchyPath = async (hierarchyId: string): Promise<hierarchies[]> => {
    const path: hierarchies[] = [];
    let currentHierarchy = await hierarchies.findByPk(hierarchyId);

    while (currentHierarchy) {
        path.push(currentHierarchy);
        if (currentHierarchy.parent_hierarchy_id) {
            currentHierarchy = await hierarchies.findByPk(currentHierarchy.parent_hierarchy_id);
        } else {
            break;
        }
    }

    return path.reverse();
};

export const getMinMaxRatesByParams = async (
    request: FastifyRequest<{ Querystring: { job_template_id: string; currency: string; unit_of_measure: string; hierarchy_ids: string, is_shift_rate: boolean; }, Params: { program_id: string } }>,
    reply: FastifyReply
) => {
    const traceId = generateCustomUUID();
    const { job_template_id, currency, unit_of_measure, hierarchy_ids, is_shift_rate } = request.query;
    const { program_id } = request.params;
    if (!job_template_id || !currency || !unit_of_measure || !hierarchy_ids) {
        return reply.status(400).send({
            status_code: 400,
            message: 'Missing required query parameters: job_template_id, currency, unit_of_measure, and hierarchy_ids are all required.',
            trace_id: traceId,
        });
    }
    try {
        const hierarchyIdsArray = hierarchy_ids.split(',');
        const hierarchyIdsJSON = JSON.stringify(hierarchyIdsArray);
        const minMaxRateResult = await sequelize.query<MinMaxRateResult>(minMaxRateQuery({
            hierarchyIdsJSON,
            jobTemplateId: job_template_id,
            currency,
            programId: program_id,
            unit_of_measure,
            is_shift_rate
        }), {
            type: QueryTypes.SELECT,
        });

        const rateModels = await Promise.all(
            hierarchyIdsArray.map(async (id) => {
                const hierarchy = await hierarchies.findByPk(id);
                return hierarchy?.rate_model;
            })
        );

        const firstRateModel = rateModels[0];
        let rate_model;
        const allSameRateModel = rateModels.every(rateModel => rateModel === firstRateModel);
        if (allSameRateModel) {
            rate_model = rateModels[0];
        }
        else {
            const paths = await Promise.all(
                hierarchyIdsArray.map(id => getHierarchyPath(id))
            );

            let commonAncestor = null;
            for (let i = 0; i < paths[0].length; i++) {
                const currentNode = paths[0][i];
                if (paths.every(path => path[i]?.id === currentNode.id && path[i]?.program_id === program_id)) {
                    commonAncestor = currentNode;
                } else {
                    break;
                }
            }
            rate_model = commonAncestor?.rate_model;
        }
        if (minMaxRateResult.length === 0) {
            return reply.status(200).send({
                status_code: 200,
                message: 'No min rate and max rate found!',
                trace_id: traceId,
                result: {
                    min_rate: null,
                    max_rate: null,
                    rate_model: rate_model || null
                }
            });
        }

        const finalResult: MinMaxRateResult = {
            min_rate: minMaxRateResult[0]?.min_rate || null,
            max_rate: minMaxRateResult[0]?.max_rate || null,
            rate_model: rate_model ?? null
        };

        reply.status(200).send({
            status_code: 200,
            message: 'Min rate and max rate found successfully!',
            trace_id: traceId,
            result: finalResult
        });

    } catch (error) {
        console.error(error);
        reply.status(500).send({
            status_code: 500,
            message: 'Internal server error',
            trace_id: traceId,
        });
    }
};
