import { FastifyInstance } from 'fastify';
import {
  getProgramModuleById,
  getProgramModuleByIdAndQuery,
  getProgramModuleByProgramId,
  getProgramModuleByIdAndQueryForWorkFlow
} from '../controllers/programModuleController';

async function programModuleRoutes(fastify: FastifyInstance) {
  fastify.get('/:id', getProgramModuleById);
  fastify.get('/get-rule-modules/:id', getProgramModuleByIdAndQuery);
  fastify.get('/program/:program_id', getProgramModuleByProgramId);
  fastify.get('/get-workflow-modules/:id', getProgramModuleByIdAndQueryForWorkFlow);
}

export default programModuleRoutes;