import { FastifyInstance } from 'fastify';
import {
    saveRateType,
    getAllRateType,
    getRateTypeById,
    updateRateTypeById,
    deleteRateTypeById,
    getRateTBYId
} from '../controllers/rateTypeController';

async function rateTypeRoutes(fastify: FastifyInstance) {
    fastify.post('/', saveRateType);
    fastify.get('/get-all', getAllRateType);
    fastify.get('/:id', getRateTypeById);
    fastify.put('/:id', updateRateTypeById);
    fastify.delete('/:id', deleteRateTypeById);
    fastify.get('/get', getRateTBYId);
}

export default rateTypeRoutes;
