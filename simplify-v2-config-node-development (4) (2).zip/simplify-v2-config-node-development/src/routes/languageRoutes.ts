import { FastifyInstance } from 'fastify';
import { searchLanguage, deleteLanguage, updateLanguage, createLanguage, getLanguageById, getLanguages,bulkUploadLanguage } from '../controllers/languageController';

async function languageRoutes(fastify: FastifyInstance) {
    fastify.post('/', createLanguage);
    fastify.get('/', getLanguages);
    fastify.get('/:id', getLanguageById);
    fastify.put('/:id', updateLanguage);
    fastify.delete('/:id', deleteLanguage);
    fastify.get('/search-languages', searchLanguage)
    fastify.post('/bulk-upload', bulkUploadLanguage);

}
export default languageRoutes;
