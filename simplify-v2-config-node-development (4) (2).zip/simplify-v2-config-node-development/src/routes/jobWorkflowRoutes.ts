import { FastifyInstance } from 'fastify';
import {
    getAllJobWorkFlow,
    getJobWorkFlowById,
    createJobWorkFlow,
    updateJobWorkFlow,
    deleteJobWorkFlow,
    getWorkflowForJob
} from '../controllers/jobWorkflowController';

async function JobWorkFlowRoutes(fastify: FastifyInstance) {
    fastify.get('/program/:program_id/job-workflow', getAllJobWorkFlow);
    fastify.get('/program/:program_id/job-workflow/:id', getJobWorkFlowById);
    fastify.post('/program/:program_id/job-workflow', createJobWorkFlow);
    fastify.put('/program/:program_id/job-workflow/:id', updateJobWorkFlow);
    fastify.delete('/program/:program_id/job-workflow/:id', deleteJobWorkFlow);
    fastify.get('/program/:program_id/workflow-approval', getWorkflowForJob);
}

export default JobWorkFlowRoutes;