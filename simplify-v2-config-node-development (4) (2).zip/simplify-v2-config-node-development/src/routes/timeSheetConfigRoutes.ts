import { FastifyInstance } from "fastify";
import {
    createTimeSheetConfig,
    getTimeSheetConfigById,
    updateTimeSheetConfigById,
    deleteTimeSheetById,
    getAllTimeSheetConfigByProgramId,
    timeSheetConfigAdvancedFilter,
    getAllHierarchies
} from "../controllers/timeSheetConfigControllers";

async function timeSheetConfigRoutes(fastify: FastifyInstance) {
    fastify.post("/timesheet-config", createTimeSheetConfig);
    fastify.get("/timesheet-config/:id", getTimeSheetConfigById);
    fastify.get("/timesheet-config", getAllTimeSheetConfigByProgramId);
    fastify.put("/timesheet-config/:id", updateTimeSheetConfigById);
    fastify.delete("/timesheet-config/:id", deleteTimeSheetById);
    fastify.post("/timesheet-config/advanced-filter", timeSheetConfigAdvancedFilter);
    fastify.get("/timesheet-config/get-all-hierarchies",getAllHierarchies )


}

export default timeSheetConfigRoutes;