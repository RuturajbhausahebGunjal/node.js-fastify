import { FastifyInstance } from 'fastify';
import { getUser, getUserById,getAllUserIDAndUserId, createUser, updateUser, deleteUser, searchUser ,getUserHierarchiesByProgram} from '../controllers/userController';

async function userRoutes(fastify: FastifyInstance) {
    fastify.get('/', getUser);
    fastify.get('/:id', getUserById);
    fastify.post('/',createUser);
    fastify.put('/:id/program/:program_id', updateUser);
    fastify.delete('/:id', deleteUser);
    fastify.get('/search-user', searchUser);
    fastify.get('/program/:program_id', getAllUserIDAndUserId);
    fastify.get('/:id/program/:program_id', getUserHierarchiesByProgram);

}
export default userRoutes;
