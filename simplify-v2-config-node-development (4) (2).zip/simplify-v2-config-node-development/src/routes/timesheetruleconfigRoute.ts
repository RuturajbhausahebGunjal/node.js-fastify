import { FastifyInstance } from "fastify";
import { getAllTimeSheetConfigByProgramId, getTimeSheetConfigRuleById, getAllTimeSheetConfig, timeSheetConfigAdvancedFilter, createTimeSheetConfigRule, updateTimeSheetConfigRuleById, deleteTimeSheetRuleById, } from "../controllers/timesheetruleconfigController";
export async function timesheetRuleRoutes(fastify: FastifyInstance) {
    fastify.get("/timesheet-config-rule", getAllTimeSheetConfigByProgramId);
    fastify.get("/timesheet-config-getall", getAllTimeSheetConfig);
    fastify.get("/timesheet-config-rule/:id", getTimeSheetConfigRuleById);
    fastify.post("/timesheet-config-rule", createTimeSheetConfigRule);
    fastify.put("/timesheet-config-rule/:id", updateTimeSheetConfigRuleById);
    fastify.delete("/timesheet-config-rule/:id", deleteTimeSheetRuleById);
    fastify.post("/timesheet-config-rule/advanced-filter", timeSheetConfigAdvancedFilter);
}

export default timesheetRuleRoutes;

