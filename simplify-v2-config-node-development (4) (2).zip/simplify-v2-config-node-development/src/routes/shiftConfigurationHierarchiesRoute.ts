import { FastifyInstance } from 'fastify';
import {
  getShiftConfigurationHierarchies,
  deleteShiftConfigurationHierarchies,
  updateShiftConfigurationHierarchies,
  createShiftConfigurationHierarchies,
  getShiftConfigurationHierarchiesById,
  postRateTypesByShiftType,
  postRateTypesByShiftTypeSchema
} from '../controllers/shiftConfigurationHierarchiesController';

async function shiftConfigurationHierarchiesRoutes(fastify: FastifyInstance) {
  fastify.post('/shift-configuration-hierarchie', createShiftConfigurationHierarchies);
  fastify.get('/program/:program_id/shift-configuration-hierarchie/:id', getShiftConfigurationHierarchiesById);
  fastify.put('/program/:program_idshift-configuration-hierarchie/:id', updateShiftConfigurationHierarchies);
  fastify.delete('/program/:program_id/shift-configuration-hierarchie/:id', deleteShiftConfigurationHierarchies);
  fastify.get('/program/:program_id/shift-configuration-hierarchies', getShiftConfigurationHierarchies);
  fastify.route({
    method: 'POST',
    url: '/get-rate-configurations',
    schema: postRateTypesByShiftTypeSchema,
    handler: postRateTypesByShiftType
  });
}

export default shiftConfigurationHierarchiesRoutes;