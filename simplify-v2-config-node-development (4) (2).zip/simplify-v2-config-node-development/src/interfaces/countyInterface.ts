export interface countyInterface {
    id: string;
    name?: string;
    region?: string;
    is_enabled: boolean;
    created_on: any;
    modified_on: any;
    state_id: string;
    created_by?: any;
    modified_by?: any;
    ref_id?: string;
    is_deleted: boolean;
}