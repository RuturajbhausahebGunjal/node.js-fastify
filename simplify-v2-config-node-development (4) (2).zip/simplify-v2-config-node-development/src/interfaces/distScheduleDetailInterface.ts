export interface distScheduleDetail {
    id: string;
    duration: number;
    vendor_distrubution_id:any;
    measure_unit: string;
    vendors: any;
    is_enabled: boolean;
    is_deleted: boolean;
    created_on: Date;
    modified_on: Date;
    created_by: string;
    modified_by: string;
}
