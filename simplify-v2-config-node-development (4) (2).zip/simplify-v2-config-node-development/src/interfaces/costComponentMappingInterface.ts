export interface costComponentMappingData {
    id: string,
    program_id: string,
    cost_component_id: string,
    created_by: string;
    modified_by: string;
    created_on: any;
    modified_on: any;
}
