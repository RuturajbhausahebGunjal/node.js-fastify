export interface RuleBuilderHierarchyMappingData {
  id?: string;
  program_id?:string;
  hierarchy_id?:string;
  rule_id?:string;
  is_enabled?: boolean;
  created_on?: number; 
  modified_on?: number;
  created_by?: string; 
  modified_by?: string; 
  is_deleted?: boolean;
}