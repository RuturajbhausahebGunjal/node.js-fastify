export interface customFieldmasterDataInterface {
    id?:string;
    program_id?: string;
    customField_id?: string;
   master_data_id?: string;
    is_deleted: boolean;
    is_enabled: boolean;
    created_on: Date;
    
  }