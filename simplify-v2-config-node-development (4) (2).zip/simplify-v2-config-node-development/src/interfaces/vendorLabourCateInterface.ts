export interface vendorLabourCategoriesInterface {
    id: string;
    program_vendor_id: string;
    labour_category_id: string;
    labour_category_name: string;
    program_id: string;
}
 