export interface WorkflowMethodData {
    id: string,
    name: String,
    description: string,
    is_enabled: boolean,
    created_on: Date,
    modified_on: Date,
    created_by: string,
    modified_by: string,
    program_id: string,
    is_deleted: boolean,
    module_id: string,
    event_id: string,
}
