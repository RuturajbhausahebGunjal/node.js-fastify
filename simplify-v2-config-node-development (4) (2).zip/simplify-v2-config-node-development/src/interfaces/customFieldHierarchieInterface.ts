export interface customFieldHierarchieInterface {
    id?:string;
    program_id?: string;
    customField_id?: string;
    hierarchie_id?: string;
    is_deleted: boolean;
    is_enabled: boolean;
    created_on: Date;
  }