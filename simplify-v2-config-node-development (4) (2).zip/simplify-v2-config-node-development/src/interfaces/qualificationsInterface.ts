export interface QualificationData {
    title: string;
    qualification_type_id: string;
    id: string,
    name: String,
    code: string,
    type: string,
    is_enabled: boolean,
    created_on: Date,
    modified_on: Date,
    created_by: string,
    modified_by: string,
    program_id: string,
    is_deleted: boolean,
}
