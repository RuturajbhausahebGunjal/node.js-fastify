

export interface WorkflowDataSourceData {
  id?: string;
  name: string;
  slug: string;
  api_url?: string;
  db_model?: string;
  is_enabled?: boolean;
  created_on?: number;
  modified_on?: number;
  created_by?: string;
  modified_by?: string;
  is_deleted?: boolean;
}
