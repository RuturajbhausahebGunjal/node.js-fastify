export interface RecipientTypesData {
    id: string,
    name: String,
    module_id: string,
    event_id: string,
    slug: string,
    meta_data: any,
    is_chain: boolean,
    parameter_schema: any,
    method_id: string,
    created_on: number,
    modified_on: number,
    created_by: string,
    modified_by: string,
    is_deleted: boolean,
    is_enabled: boolean
}
