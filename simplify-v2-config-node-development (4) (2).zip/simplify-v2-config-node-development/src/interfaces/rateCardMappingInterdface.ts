export interface RateCardMappingData {
    id: string,
    rate_card_config_id: string,
    program_id: string,
    hierarchy_id: string,
    unit_of_measure: any
}
