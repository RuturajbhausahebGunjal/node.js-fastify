
export interface customFieldLocationInterface{
    id?: string;  
    program_id?:string
    custom_field_id: string;  
    location_id: string;  
    is_enabled: boolean;  
    is_deleted?: boolean;  
}