interface CurrenciesData {
    name: string;
    label: string;
    symbol: string;
    code: string;
  }
  export default CurrenciesData;
  