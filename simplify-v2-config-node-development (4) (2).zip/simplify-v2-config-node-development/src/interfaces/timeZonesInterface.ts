
export interface TimeZone {
    id: string;
    code: string;
    name: string;
    offset: number;
    utcOffset: string;
    region: string;
    num: string;
  }