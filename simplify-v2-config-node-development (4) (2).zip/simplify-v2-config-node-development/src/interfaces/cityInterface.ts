export interface cityData {
  id?: string;
  resources_state_id?: string;
  name?: string;
  is_enabled?: boolean;
  created_on?: number;
  modified_on?: number;
  created_by?: string;
  modified_by?: string;
  is_deleted?: boolean;
  state_id?:string,
  county_id?:string;
  ref_id?: string;
}
