import { DataTypes, Model } from "sequelize";
import { sequelize } from "../config/instance";
import { convertEmptyStringsToNull } from "../hooks/convertEmptyStringsToNull";
import { beforeSave } from "../hooks/timeFormatHook";
import WorkflowDataSource from "../models/workflowDataSourceModel";

class WorkflowField extends Model { }

WorkflowField.init(
    {
        id: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true,
        },
        name: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        slug: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        api_url: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        field_type: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        field_meta: {
            type: DataTypes.JSON,
            allowNull: true,
        },
        data_source_id: {
            type: DataTypes.UUID,
            allowNull: true,
            references: {
                model: "workflow_data_source",
                key: "id",
            },
        },
        is_enabled: {
            type: DataTypes.BOOLEAN,
            defaultValue: true,
        },
        created_on: {
            type: DataTypes.DOUBLE,
        },
        modified_on: {
            type: DataTypes.DOUBLE,
        },
        created_by: {
            type: DataTypes.UUID,
            allowNull: true,
        },
        modified_by: {
            type: DataTypes.UUID,
            allowNull: true,
        },
        is_deleted: {
            type: DataTypes.BOOLEAN,
            defaultValue: false,
        }
    },
    {
        sequelize,
        tableName: "workflow_field",
        timestamps: false,
        hooks: {
            beforeValidate: (instance) => {
                convertEmptyStringsToNull(instance);
            },
            beforeSave: (instance) => {
                beforeSave(instance);
            },
        },
    }
);

sequelize.sync();
WorkflowField.belongsTo(WorkflowDataSource, {
    foreignKey: "data_source_id",
    as: "data_source",
});

export default WorkflowField;
