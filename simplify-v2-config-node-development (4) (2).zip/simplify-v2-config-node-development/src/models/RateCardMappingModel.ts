import { DataTypes, Model } from "sequelize";
import { sequelize } from "../config/instance";
import { convertEmptyStringsToNull } from "../hooks/convertEmptyStringsToNull";
import { beforeSave } from "../hooks/timeFormatHook";

class RateCardMapping extends Model {
    hierarchy_id: any;
}

RateCardMapping.init(
    {
        id: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true,
        },
        rate_card_config_id: {
            type: DataTypes.UUID,
            allowNull: true
        },
        program_id: {
            type: DataTypes.UUID,
            allowNull: false,
        },
        hierarchy_id: {
            type: DataTypes.UUID,
            allowNull: false
        },
        created_on: {
            type: DataTypes.DOUBLE
        },
        modified_on: {
            type: DataTypes.DOUBLE
        },
        is_enabled: {
            type: DataTypes.BOOLEAN,
            defaultValue: true,
        },
        is_deleted: {
            type: DataTypes.BOOLEAN,
            defaultValue: false,
        }
    },
    {
        sequelize,
        tableName: "rate_card_mapping",
        timestamps: false,
        hooks: {
            beforeValidate: (instance) => {
                convertEmptyStringsToNull(instance);
            },
            beforeSave: (instance) => {
                beforeSave(instance);
            },
        },
    }
);

sequelize.sync();

export default RateCardMapping;
