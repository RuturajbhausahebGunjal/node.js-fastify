import { DataTypes, Model } from 'sequelize';
import { sequelize } from '../config/instance';
import { Programs } from './programsModel';
import { beforeSave } from "../hooks/timeFormatHook";
import { convertEmptyStringsToNull } from '../hooks/convertEmptyStringsToNull';
import CountryModel from './countriesModel';
import TimeZone from "./timeZoneModel";
import Language from "./languageModel";
import hierarchies from "./hierarchiesModel";
import WorkLocationModel from "./workLocationModel";

class User extends Model {
  id: string | undefined;
  default_work_location_id: string | undefined;
  default_hierarchy_id: string | undefined;
  language_id: string | undefined;
  country_id: string | undefined;
  time_zone_id: string | undefined;
  public associate_hierarchy_ids!: string[];
  public work_location_ids!: string[];
  tenant_id: any;
  hierarchies: any;
  addresses: any;
  work_locations: any;
  user_type: string | undefined;;
}

User.init(
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      allowNull: false,
      primaryKey: true,
    },
    program_id: {
      type: DataTypes.UUID,
      allowNull: true,
      references: {
        model: 'programs',
        key: 'id',
      },
    },
    tenant_id: {
      type: DataTypes.UUID,
      allowNull: true
    },
    user_type: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    name_prefix: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    first_name: {
      type: DataTypes.STRING,
      allowNull: true
    },
    addresses: {
      type: DataTypes.JSON,
      allowNull: true
    },
    role_id: {
      type: DataTypes.STRING,
      allowNull: true
    },
    contacts: {
      type: DataTypes.JSON,
      allowNull: true
    },
    middle_name: {
      type: DataTypes.STRING,
      allowNull: true
    },
    last_name: {
      type: DataTypes.STRING,
      allowNull: true
    },
    username: {
      type: DataTypes.STRING,
      allowNull: true
    },
    name_suffix: {
      type: DataTypes.STRING,
      allowNull: true
    },
    email: {
      type: DataTypes.STRING,
      allowNull: true
    },
    sso_id: {
      type: DataTypes.STRING,
      allowNull: true
    },
    title: {
      type: DataTypes.STRING,
      allowNull: true
    },
    avatar: {
      type: DataTypes.JSON,
      allowNull: true
    },
    theme: {
      type: DataTypes.JSON,
      allowNull: true
    },
    country_id: {
      type: DataTypes.STRING,
      allowNull: true,
      references: {
        model: 'countries',
        key: 'id',
      },
    },
    applications: {
      type: DataTypes.JSON,
      allowNull: true
    },
    credentials: {
      type: DataTypes.JSON,
      allowNull: true
    },
    supervisor: {
      type: DataTypes.STRING,
      allowNull: true
    },
    time_zone_id: {
      type: DataTypes.STRING,
      allowNull: true,
      references: {
        model: 'time_zones',
        key: 'id',
      },
    },
    language_id: {
      type: DataTypes.STRING,
      allowNull: true,
      references: {
        model: 'language',
        key: 'id',
      },
    },
    associate_hierarchy_ids: {
      type: DataTypes.JSON,
      allowNull: true,
    },
    work_location_ids: {
      type: DataTypes.JSON,
      allowNull: true,
    },
    associate_cost_ids: {
      type: DataTypes.JSON,
      allowNull: true,
    },
    spend_category_ids: {
      type: DataTypes.JSON,
      allowNull: true,
    },
    is_all_hierarchy_associate: {
      type: DataTypes.BOOLEAN,
      allowNull: true
    },
    default_hierarchy_id: {
      type: DataTypes.STRING,
      allowNull: true
    },
    is_all_work_location_associate: {
      type: DataTypes.BOOLEAN,
      allowNull: true
    },
    default_work_location_id: {
      type: DataTypes.STRING,
      allowNull: true
    },
    is_all_cost_center_associate: {
      type: DataTypes.BOOLEAN,
      allowNull: true
    },
    default_cost_center_id: {
      type: DataTypes.STRING,
      allowNull: true
    },
    is_all_spend_category_associate: {
      type: DataTypes.BOOLEAN,
      allowNull: true
    },
    default_spend_category_id: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    is_allow_unlimited_autherity: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
    min_limit: {
      type: DataTypes.DOUBLE,
      allowNull: true,
    },
    max_limit: {
      type: DataTypes.DOUBLE,
      allowNull: true,
    },
    is_enabled: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
      defaultValue: true
    },
    is_activated: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
    is_deleted: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
      defaultValue: false
    },
    created_on: {
      type: DataTypes.DOUBLE,
    },
    modified_on: {
      type: DataTypes.DOUBLE,
    },
    created_by: {
      type: DataTypes.UUID,
      allowNull: true,
    },
    modified_by: {
      type: DataTypes.UUID,
      allowNull: true,
    }
  },
  {
    sequelize,
    tableName: 'user',
    timestamps: false,
    hooks: {
      beforeValidate: (instance) => {
        convertEmptyStringsToNull(instance);
      },
      beforeSave: async (instance) => {
        beforeSave(instance);
      },
    }
  }
);

User.belongsTo(Programs, { foreignKey: "program_id", as: "programs" });
User.belongsTo(CountryModel, { foreignKey: "country_id", as: "countries" });
User.belongsTo(TimeZone, { foreignKey: "time_zone_id", as: "time_zone" });
User.belongsTo(Language, { foreignKey: "language_id", as: "language" });
User.belongsToMany(hierarchies, { through: 'user_hierarchies', foreignKey: 'user_Id' });
User.belongsToMany(WorkLocationModel, { through: 'user_work_locations', foreignKey: 'user_Id' });


export default User;