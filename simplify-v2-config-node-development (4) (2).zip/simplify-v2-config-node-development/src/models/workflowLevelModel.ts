import { DataTypes, Model } from "sequelize";
import { sequelize } from "../config/instance";
import { Programs } from "./programsModel";
import Workflow from "./workflowModel";
import { convertEmptyStringsToNull } from "../hooks/convertEmptyStringsToNull";
import { beforeSave } from "../hooks/timeFormatHook";

class WorkflowLevel extends Model {
    id: any;
}

WorkflowLevel.init(
    {
        id: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true,
        },
        is_enabled: {
            type: DataTypes.BOOLEAN,
            defaultValue: true,
        },
        is_deleted: {
            type: DataTypes.BOOLEAN,
            defaultValue: false,
        },
        created_on: {
            type: DataTypes.DOUBLE,
            allowNull: true,
        },
        modified_on: {
            type: DataTypes.DOUBLE,
            allowNull: true,
        },
        created_by: {
            type: DataTypes.UUID,
            allowNull: true,
        },
        modified_by: {
            type: DataTypes.UUID,
            allowNull: true,
        },
        placement_order: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        program_id: {
            type: DataTypes.UUID,
            references: {
                model: "programs",
                key: "id",
            },
        },
        workflow_id: {
            type: DataTypes.UUID,
            references: {
                model: "workflow",
                key: "id",
            },
        }
    },
    {
        sequelize,
        tableName: "workflow_level",
        timestamps: false,
        hooks: {
            beforeValidate: (instance) => {
                convertEmptyStringsToNull(instance);
            },
            beforeSave: (instance) => {
                beforeSave(instance);
            },
        },
    }
);

sequelize.sync();
WorkflowLevel.belongsTo(Programs, {
    foreignKey: "program_id",
    as: "programs",
});

WorkflowLevel.belongsTo(Workflow, {
    foreignKey: "workflow_id",
    as: "workflow",
});

export default WorkflowLevel;
