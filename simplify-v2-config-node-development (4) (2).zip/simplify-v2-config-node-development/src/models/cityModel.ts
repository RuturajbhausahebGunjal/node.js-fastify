import { DataTypes, Model } from "sequelize";
import { sequelize } from "../config/instance";
import { beforeSave } from "../hooks/timeFormatHook";
import { convertEmptyStringsToNull } from "../hooks/convertEmptyStringsToNull";
import stateModel from "./stateModel";
import countyModel from "./countyModel";
class cityModel extends Model {
  [x: string]: any;
}
cityModel.init({
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    allowNull: false,
    primaryKey: true,
  },
  state_id: {
    type: DataTypes.UUID,
    allowNull: true,
    references: {
      model: stateModel,
      key: "id",
    },
    onUpdate: "CASCADE",
    onDelete: "SET NULL",
  },
  county_id: {
    type: DataTypes.UUID,
    allowNull: true,
    references: {
      model: countyModel,
      key: "id"
    }
  },
  name: {
    type: DataTypes.STRING,
    allowNull: true,
    unique: true,
  },
  is_enabled: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true,
  },
  created_on: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },
  modified_on: {
    type: DataTypes.DOUBLE,
    allowNull: true,
  },
  created_by: {
    type: DataTypes.UUID,
    allowNull: true,
  },
  modified_by: {
    type: DataTypes.UUID,
    allowNull: true,
  },
  is_deleted: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: false,
  },
  ref_id: {
    type: DataTypes.UUID,
    allowNull: true,
  },
}, {
  sequelize,
  tableName: "city",
  timestamps: false,
  hooks: {
    beforeValidate: (instance) => {
      convertEmptyStringsToNull(instance);
    },
    beforeSave: (instance) => {
      beforeSave(instance);
    },
  },
});

cityModel.belongsTo(stateModel, { foreignKey: "state_id", as: "state" });
cityModel.belongsTo(countyModel, { foreignKey: "county_id" });

export default cityModel;
