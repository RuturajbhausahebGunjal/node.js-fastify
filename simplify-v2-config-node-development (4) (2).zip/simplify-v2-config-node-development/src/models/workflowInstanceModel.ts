import { DataTypes, Model } from "sequelize";
import { sequelize } from "../config/instance";
import { convertEmptyStringsToNull } from "../hooks/convertEmptyStringsToNull";
import { beforeSave } from "../hooks/timeFormatHook";
import WorkflowMethod from "./workflowMethodsModel";
import { Programs } from "./programsModel";
import { Module } from "./moduleModel";
import Event from "./eventModel";
import Workflow from "./workflowModel";

class WorkFlowInstance extends Model { }

WorkFlowInstance.init(
    {
        id: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true,
        },
        is_enabled: {
            type: DataTypes.BOOLEAN,
            defaultValue: true,
        },
        created_on: {
            type: DataTypes.DOUBLE,
        },
        modified_on: {
            type: DataTypes.DOUBLE,
        },
        created_by: {
            type: DataTypes.UUID,
            allowNull: true,
        },
        modified_by: {
            type: DataTypes.UUID,
            allowNull: true,
        },
        is_deleted: {
            type: DataTypes.BOOLEAN,
            defaultValue: false,
        },
        program_id: {
            type: DataTypes.UUID,
            allowNull: false,
            references: {
                model: "programs",
                key: "id",
            },
        },
        workflow_id: {
            type: DataTypes.UUID,
            allowNull: true,
            references: {
                model: "workflow",
                key: "id",
            },
        },
        module_id: {
            type: DataTypes.UUID,
            allowNull: true,
            references: {
                model: "module",
                key: "id",
            },
        },
        event_id: {
            type: DataTypes.UUID,
            allowNull: true,
            references: {
                model: "event",
                key: "id",
            },
        },
        method_id: {
            type: DataTypes.UUID,
            allowNull: true,
            references: {
                model: "workflow_methods",
                key: "id",
            },
        },
    },
    {
        sequelize,
        tableName: "workflow_instances",
        timestamps: false,
        hooks: {
            beforeValidate: (instance) => {
                convertEmptyStringsToNull(instance);
            },
            beforeSave: (instance) => {
                beforeSave(instance);
            },
        },
    }
);

sequelize.sync();
WorkFlowInstance.belongsTo(Programs, {
    foreignKey: "program_id",
    as: "programs",
});
WorkFlowInstance.belongsTo(Module, {
    foreignKey: "module",
    as: "Module",
});
WorkFlowInstance.belongsTo(Event, {
    foreignKey: "event_id",
    as: "event",
});
WorkFlowInstance.belongsTo(WorkflowMethod, {
    foreignKey: "method_id",
    as: "method",
});
WorkFlowInstance.belongsTo(Workflow, {
    foreignKey: "workflow_id",
    as: "workflow",
});

export default WorkFlowInstance;
