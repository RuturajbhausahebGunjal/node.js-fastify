import { Model } from 'sequelize';
import ProgramModule from '../models/programModuleModel';
import { Module } from '../models/moduleModel';
import hierarchies from '../models/hierarchiesModel';
import generateSlug from '../plugins/slugGenerate';
import qualificationTypeModel from '../models/qualificationTypeModel'
import { rateType } from '../models/rateTypeModel';
export const createProgramModule = async (record: Model) => {
    // Create a record in the program_module table
    let modules = await Module.findAll({
        where: {
            is_deleted: false,
            parent_module_id: null
        },
    });
    let module = modules.map((module: any) => ({
        module_id: module?.id,
        is_enabled: module?.is_enabled,
    }));
    await ProgramModule.create({
        program_id: (record as any).id,
        modules: module,
    });
};

// Create a hierarchy for the program
export const createHierarchy = async (record: Model) => {
    let code = generateSlug((record as any).name, {
        trim: true,
        removedspecial: true,
    });
    let a = await hierarchies.create({
        program_id: (record as any).id,
        name: (record as any).name,
        code: "--",
        hierarchy_level: 1,
        hierarchy_order: 1,
        is_enabled: true,
        rate_model: "Bill Rate (No Markup)",
        preferred_date_format: "DD/MM/YYYY",
        is_vendor_neutral: false,
        is_rate_card_enforced: false,
        is_hidden: false,
    });
    console.log(a);
};

export const createQualificationTypes = async (record: Model) => {
    const defaultQualificationTypes = [
        { name: 'Skill', code: 'skill', type: 'Predefined' },
        { name: 'Education', code: 'education', type: 'Predefined' },
        { name: 'Certificates', code: 'certificate', type: 'Predefined' },
        { name: 'Vaccination', code: 'vaccination', type: 'Predefined' },
        { name: 'Speciality', code: 'speciality', type: 'Predefined' },
        { name: 'Document', code: 'document', type: 'Predefined' },
    ];

    for (let qualification of defaultQualificationTypes) {
        await qualificationTypeModel.create({
            program_id: (record as any).id,
            name: qualification.name,
            code: qualification.code,
            type: qualification.type,
            is_enabled: true,
            is_deleted: false,
            created_by: (record as any).created_by,
            modified_by: (record as any).modified_by,
        });
    }
};

export const createRateTypes = async (record: Model) => {
    await rateType.create({
        program_id: (record as any).id,
        name: "Standard",
        type: "Standard",
        description: "standard bill rate and pay rate",
        bill_rate: [
            {
                "differential_type": "Factor Differential",
                "differential_on": "Bill Rate",
                "differential_value": 1.00
            }
        ],
        pay_rate: [
            {
                "differential_type": "Fixed Differential",
                "differential_on": "Pay Rate",
                "differential_value": 1.00
            }
        ],
        abbreviation: "ST",
        is_enabled: true,
        is_deleted: false,
        is_shift_rate: false,
        is_billable: true,
        created_by: (record as any).created_by,
        modified_by: (record as any).modified_by,
    });
}